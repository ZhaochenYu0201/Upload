# Exp #11 — Distance-binned accuracy (does sparse degrade at long range?)

## What this experiment is

A **post-hoc, 0-GPU** analysis answering: *does the sparse-vs-dense gap grow with context
length?* (i.e. does SFI lose long-range information?). It re-scores existing LongBench-V1
predictions **per example**, bins each example by its context length, and reports
dense vs sparse accuracy within each bin.

- Model: Qwen3-30B-A3B-Instruct. Dense = `results_qwen_dense_v1`;
  sparse = `results_qwen_30b_sparse_new_gpu0_bs1`.
- Method: per-example `dataset2metric` scoring (LongBench-V1), then mean within each
  context-length bin. (Per-example mean differs from per-task mean — see note — but the
  **gap-by-bin** is the robust conclusion.)
- Dense baseline (per-task) for reference: **46.83** (Qwen3-30B-A3B-Instruct, V1,
  MAX_MODEL_LEN=262144).

## Headline result

Coarse bins:

| Bin | Dense | Sparse | Gap | N |
|---|---|---|---|---|
| <8k | 44.24 | 43.34 | -0.90 | 2747 |
| 8–32k | 44.01 | 42.54 | -1.47 | 1956 |
| 32–64k | 31.27 | 30.68 | -0.59 | 47 |

Finer bins:

| Bin | Dense | Sparse | Gap | N |
|---|---|---|---|---|
| <4k | 35.58 | 35.00 | -0.58 | 1549 |
| 4–8k | 55.44 | 54.12 | -1.32 | 1198 |
| 8–16k | 46.66 | 45.62 | -1.04 | 1523 |
| 16–32k | 34.68 | 31.70 | -2.98 | 433 |
| >32k | 31.27 | 30.68 | -0.59 | 47 |

**Conclusion:** the sparse–dense gap is **small (-0.6 to -1.5) and does NOT grow
monotonically with context length**. The single larger value (16–32k, -2.98) is a
small-sample (N=433) fluctuation; the longest bin (>32k) returns to -0.59. SFI is
**near-lossless across all distance bins** and does **not** degrade in long context —
directly supporting the claim that SFI preserves long-range information.

## Notes / caveats

- Per-example mean here (dense ~44) uses a different aggregation than the per-task mean
  (Table 8 dense 46.83); the **gap-by-bin** is the load-bearing, robust result.
- LongBench-V1 has **no >64k examples**, so the very-long regime is bounded by the dataset.
- This is a re-scoring of existing predictions: **no GPU** needed. The sparse config is
  swappable (here `qwen_30b_sparse_new`).

## How to run

Re-score the two prediction sets per example and bin by context length (the analysis was
run against the prediction dirs on the remote box):
- dense: `…/fast-slow/attention-xx-point/LongBench/results_qwen_dense_v1/`
- sparse: `…/LongBench/results_qwen_30b_sparse_new_gpu0_bs1/`

The scoring uses LongBench's own `dataset2metric` per example, then groups by the
example's context token length. (Full per-bin numbers are reproduced above and in
`_raw_result_logs/phi_crossfamily_results.txt`, section "#11 距离分桶".)
