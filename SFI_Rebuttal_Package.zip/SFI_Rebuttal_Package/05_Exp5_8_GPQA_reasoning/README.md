# Exp #5 / #8 — Hard-reasoning accuracy on GPQA (Qwen3-30B-Thinking)

## What this experiment is

Reviewers asked whether SFI sparse attention hurts the model on **hard, long
chain-of-thought reasoning** (not just long-context retrieval). This experiment
runs **GPQA-diamond** (198 graduate-level science MCQs) on the **Qwen3-30B-A3B-Thinking**
model, comparing **dense** vs **sparse** at several sparse budgets (`alpha_fair.k_head`),
i.e. an **activation/budget sweep (#5)**.

The Thinking model emits very long CoT (often 20k–32k output tokens per question), which
is exactly the regime where token-dropping sparse attention could plausibly hurt.

## Headline result

| Config | `alpha_fair.k_head` | GPQA-diamond accuracy | vs dense |
|---|---|---|---|
| Dense (full attention) | — | **69.70%** (138/198) | — |
| Sparse | 8192 | **69.70%** (same as dense) | 0.00 |
| Sparse | 4096 | **71.21%** | **+1.51** (within noise) |
| Sparse | 2048 | **68.69%** (136/198) | **-1.01** |

**Conclusion:** sparse attention is **near-lossless on hard reasoning** — every budget is
within ±1.5% of dense (Thinking-model run-to-run noise band), and accuracy is **robust to
the sparse budget**: larger `k_head` monotonically approaches dense, and even the most
aggressive confirmed point (k2048) only loses ~1 point (2 questions out of 198). This
mirrors the long-context result and closes the "does sparse hurt reasoning?" question.

## Experimental setup

- **Model:** `/mnt/bn/ecom-ai-platform-1/yzc/models/Qwen/Qwen3-30B-A3B-Thinking-2507`
- **Hardware:** NVIDIA **B200** (SM100 / FA4), one model replica per GPU
- **Server:** standard vLLM OpenAI API server from the patched vendored vLLM
  (`fst/attention-xx-point-wip-async-prefill-v2/vllm`), launched with
  `--enforce-eager` (see "Key fix" below), `--max-model-len 40960`,
  `--gpu-memory-utilization 0.85`, `--trust-remote-code`.
- **Sparse controller** (`VLLM_SPARSE_CONTROLLER_JSON`, base from
  `attention-xx-point-main/scripts/run_longbench_sparse_gpu0.sh`):
  `tau=1.0, k_min=32, k_max=null, sink=8, recent=256,
  trigger={refresh_interval:64, enable_sentence_triggers:true},
  alpha_fair={k_head: <SWEPT>, soft_alpha:1.0, cross_head_alpha:0.85, ...}`.
  The **budget knob swept is `alpha_fair.k_head` ∈ {2048, 4096, 8192}**.
- **Dense reference:** same patched vLLM with **no** `VLLM_SPARSE_CONTROLLER_JSON`.
- **Benchmark harness:** `fast-slow/benchmark-eval/run_benchmark.py` with
  `config_30b_sparse.yaml`, overridden to:
  `benchmarks=[gpqa_diamond]`, `generation.max_tokens=32000`,
  `concurrency.num_workers=8`, `model.timeout=3600`, `model.max_retries=1`,
  all 198 samples, `base_url=http://localhost:<port>/v1`, `api_key=EMPTY`.

## Key technical fix (this is why the experiment was previously blocked)

1. **cudagraph crash on the Thinking model.** The original sparse e2e harness forces a
   one-shot CUDA-graph (`--full-cuda-graph`), which the Thinking model's variable-length
   decode breaks (`full cudagraph replay refresh payload enqueue missing`). **Fix:** use
   the *standard* vLLM api_server (not the bench harness) with **`--enforce-eager`** to
   disable cudagraph capture. Decode is eager but stable; this is an accuracy run, so the
   eager slowdown is acceptable.
2. **B200 / torch compatibility.** The vendored sparse `_C` extension loads cleanly under
   the `fst` conda env's **torch 2.8.0+cu128** on B200 (CUDA 12.8) — verified before use.
3. **benchmark-eval client timeout.** The harness default is **120 s** (`config.py:17`,
   `cli.py:184 timeout=config.model.timeout`), which kills the long-CoT GPQA requests and
   triggers a retry storm. **Fix:** set `model.timeout=3600` in the config.
4. **Throughput / GPU utilization.** `num_workers=8` (vs 4) roughly doubled server decode
   throughput (~120→240 tok/s) and the GPU utilization; the full 198-question run then
   completes in ~1.5 h per config.
5. **Process cleanup between configs.** Wide `pkill -f` is blocked by the shared-box
   auto-mode AND misses vLLM's `EngineCore` child procs (which hold the GPU memory). Use
   **`os.killpg`** on the process group (by PID from `lsof -ti:<port>`), see
   `code/go_sfi_hardkill.py`. Never touch port 8000 (a co-tenant's GPU-holder).

## How to run (reproduce)

The pipeline is orchestrated by the self-managing scripts in `code/` (each ships itself
detached and writes a log). End-to-end:

```bash
# 1) launch a sparse Thinking server on GPU 0, port 8001, k_head=2048, eager
python code/go_sfi_server.py            # edits k_head inside the controller JSON

# 2) smoke test the server survives a long-CoT request
python code/go_sfi_test.py              # -> /tmp/sfi_test.log : REQ_OK + survived=True

# 3) full GPQA sparse (all 198) + a dense reference server on GPU 1
python code/go_sfi_full.py              # sparse@8001 + dense@8002, both full GPQA

# 4) k_head sweep (4096 @ GPU0, 8192 @ GPU1) in parallel
python code/go_sfi_sweep2.py            # deep-copies cj, sets alpha_fair.k_head

# cleanup between phases (process-group kill, frees the GPUs):
python code/go_sfi_hardkill.py
```

`go_sfi_relaunch_*` / `go_sfi_fix_timeout.py` / `go_sfi_clean_clients.py` are the
iteration scripts that landed the final config (nw8 / max_tokens 32000 / timeout 3600).
`go_launch2.py`, `go_bench.py`, `orch58b.py`, `run58.py`, `smoke58.py` are earlier
single-GPU attempts kept for provenance.

## Result files

- Bundled (small): `results/sfi_gpqa_summary.txt` (recorded headline numbers).
- Per-config accuracy is in `results/` where it could be pulled; the authoritative
  `metrics.json` + per-sample `results.jsonl` live on the remote box at:
  - `…/fast-slow/benchmark-eval/sfi_gpqa_dense/` (dense, 69.70%)
  - `…/fast-slow/benchmark-eval/sfi_gpqa_sparse_k2048/` (68.69%)
  - `…/fast-slow/benchmark-eval/sfi_gpqa_sparse_k4096/` (71.21%)
  - `…/fast-slow/benchmark-eval/sfi_gpqa_sparse_k8192/` (69.70%)
  (`<remote>` = `/mnt/bn/ecom-ai-platform-1/yzc`.)

## Not completed (honesty note)

`k1024` (a more-aggressive 5th sweep point), the **#8 trigger-off ablation**
(`trigger.enable_sentence_triggers=false`), and **MMLU** were scripted
(`code/go_sfi_phase2.py`) but did not finish under the throttled remote shell, so they
are **not** in this package. The 4 confirmed points already support the conclusion.
