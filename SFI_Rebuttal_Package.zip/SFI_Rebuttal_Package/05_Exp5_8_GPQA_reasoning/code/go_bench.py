import subprocess, os, yaml, shutil, glob, json
B = '/mnt/bn/ecom-ai-platform-1/yzc/fast-slow/benchmark-eval'
FST = '/mnt/bn/ecom-ai-platform-1/yzc/miniconda/envs/fst/bin/python'
cfg = yaml.safe_load(open(B + '/config_30b_sparse.yaml'))
cfg['model']['base_url'] = 'http://localhost:8013/v1'
cfg['model']['api_key'] = 'token-abc123'
cfg['evaluation']['benchmarks'] = ['gpqa_diamond']
cfg['evaluation']['generation']['max_tokens'] = 16384
cfg['evaluation']['concurrency']['num_workers'] = 2
cfg.setdefault('datasets', {}).setdefault('gpqa_diamond', {})['num_samples'] = 3
cfg['evaluation']['output']['results_dir'] = './sparse_30b_gpqa_smoke'
yaml.safe_dump(cfg, open('/tmp/cfg58.yaml', 'w'))
shutil.rmtree(B + '/sparse_30b_gpqa_smoke', ignore_errors=True)
env = dict(os.environ); env['OPENAI_API_KEY'] = 'token-abc123'
r = subprocess.run([FST, 'run_benchmark.py', '--config', '/tmp/cfg58.yaml'], cwd=B, env=env, capture_output=True, text=True, timeout=3000)
out = 'rc=' + str(r.returncode)
ms = sorted(glob.glob(B + '/sparse_30b_gpqa_smoke/*metrics.json'))
if ms:
    m = json.load(open(ms[-1]))
    out += ' acc=' + str(m.get('accuracy')) + ' correct=' + str(m.get('correct')) + ' total=' + str(m.get('total'))
    rj = sorted(glob.glob(B + '/sparse_30b_gpqa_smoke/*results.jsonl'))[-1]
    r0 = [json.loads(l) for l in open(rj)][0]
    out += ' mo_len=' + str(len(r0.get('model_output') or '')) + ' err=' + str((r0.get('metadata') or {}).get('error', 'none'))[:30]
open('/tmp/bench_out.txt', 'w').write(out)
