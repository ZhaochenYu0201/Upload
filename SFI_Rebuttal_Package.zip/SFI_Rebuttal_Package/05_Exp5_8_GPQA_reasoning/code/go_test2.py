import time, json, urllib.request
LOG = open('/tmp/test2_result.txt', 'w')
def w(m):
    LOG.write(str(m) + '\n'); LOG.flush()
up = False
for i in range(70):
    time.sleep(5)
    try:
        urllib.request.urlopen('http://localhost:8000/v1/models', timeout=3); up = True; break
    except Exception:
        pass
w('up=' + str(up) + ' waited=' + str((i + 1) * 5))
if up:
    body = json.dumps({"model": "Qwen3-30B-A3B-Thinking-2507", "messages": [{"role": "user", "content": "What is 17*23? Think step by step, then state the final answer."}], "max_tokens": 4000, "temperature": 0.6}).encode()
    try:
        req = urllib.request.Request('http://localhost:8000/v1/chat/completions', data=body, headers={'Content-Type': 'application/json'})
        resp = json.loads(urllib.request.urlopen(req, timeout=400).read())
        txt = resp['choices'][0]['message']['content']
        w('REQ_OK len=' + str(len(txt)) + ' tail=' + txt[-70:].replace(chr(10), ' '))
    except Exception as e:
        w('REQ_FAIL ' + str(e)[:130])
    try:
        urllib.request.urlopen('http://localhost:8000/v1/models', timeout=4); w('survived=True')
    except Exception:
        w('survived=False')
w('TEST2_DONE')
LOG.close()
