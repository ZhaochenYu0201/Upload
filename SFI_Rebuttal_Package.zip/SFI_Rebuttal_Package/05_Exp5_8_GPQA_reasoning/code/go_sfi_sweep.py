import subprocess, os, yaml, shutil, time, urllib.request, glob, json as J
B = '/mnt/bn/ecom-ai-platform-1/yzc/fast-slow/benchmark-eval'
FST = '/mnt/bn/ecom-ai-platform-1/yzc/miniconda/envs/fst/bin/python'
REPO = '/mnt/bn/ecom-ai-platform-1/yzc/fst/attention-xx-point-wip-async-prefill-v2'
TH = '/mnt/bn/ecom-ai-platform-1/yzc/models/Qwen/Qwen3-30B-A3B-Thinking-2507'
MAIN = '/mnt/bn/ecom-ai-platform-1/yzc/fst/attention-xx-point-main/scripts/run_longbench_sparse_gpu0.sh'
LOG = open('/tmp/sfi_sweep.log', 'w')
def w(m):
    LOG.write(str(m) + '\n'); LOG.flush()
def readacc(d):
    mj = glob.glob(B + '/' + d + '/*metrics.json')
    if mj:
        try: return round(J.load(open(mj[0])).get('accuracy', 0) * 100, 2)
        except Exception: return None
    return None
k2048 = readacc('sfi_gpqa_sparse_k2048'); dense = readacc('sfi_gpqa_dense')
summ = '/mnt/bn/ecom-ai-platform-1/yzc/sfi_gpqa_summary.txt'
with open(summ, 'a') as f:
    f.write('GPQA-diamond Thinking-30B: dense=%s%% sparse_base=%s%% delta=%s\n' % (dense, k2048, round((k2048 or 0) - (dense or 0), 2)))
w('recorded dense=%s sparse_base=%s' % (dense, k2048))
src = open(MAIN).read(); mi = src.find('VLLM_SPARSE_CONTROLLER_JSON='); q1 = src.find("'", mi); q2 = src.find("'", q1 + 1); cj0 = src[q1 + 1:q2]
try:
    cjd = J.loads(cj0); w('cj_keys=%s k_head=%s' % (list(cjd.keys()), cjd.get('k_head')))
except Exception as e:
    cjd = None; w('cj_parse_err %s :: raw=%s' % (str(e)[:40], cj0[:120]))
def cj_kh(kh):
    if cjd is not None and 'k_head' in cjd:
        d = dict(cjd); d['k_head'] = kh; return J.dumps(d)
    return '{"sink": 8, "k_head": %d}' % kh
subprocess.run(['bash', '-c', 'pgrep -f run_benchmark.py | xargs -r kill -9; for p in $(lsof -ti:8001 2>/dev/null) $(lsof -ti:8002 2>/dev/null); do kill -9 $p 2>/dev/null; done; true'])
time.sleep(6)
def launch_server(gpu, port, kh):
    env = dict(os.environ); env['CUDA_VISIBLE_DEVICES'] = gpu
    env['VLLM_SPARSE_CONTROLLER_JSON'] = cj_kh(kh); env['VLLM_SPARSE_DEBUG'] = '0'; env['PYTHONPATH'] = REPO + '/vllm'
    subprocess.Popen([FST, '-m', 'vllm.entrypoints.openai.api_server', '--model', TH, '--served-model-name', 'Qwen3-30B-A3B-Thinking-2507', '--port', port, '--max-model-len', '40960', '--gpu-memory-utilization', '0.85', '--trust-remote-code', '--enforce-eager'], cwd=REPO, env=env, stdout=open('/tmp/sfi_srv_' + port + '.log', 'w'), stderr=subprocess.STDOUT, start_new_session=True)
launch_server('0', '8001', 4096)
launch_server('1', '8002', 8192)
w('servers launched k4096@gpu0:8001 k8192@gpu1:8002')
def health(p):
    try: urllib.request.urlopen('http://localhost:' + p + '/v1/models', timeout=3); return True
    except Exception: return False
for tag, port in [('k4096', '8001'), ('k8192', '8002')]:
    up = False
    for i in range(100):
        time.sleep(5)
        if health(port): up = True; break
    w('%s_up=%s waited=%ds' % (tag, up, (i + 1) * 5))
def fire(port, resdir, logf):
    cfg = yaml.safe_load(open(B + '/config_30b_sparse.yaml'))
    cfg['model']['base_url'] = 'http://localhost:' + port + '/v1'; cfg['model']['api_key'] = 'EMPTY'; cfg['model']['model_name'] = 'Qwen3-30B-A3B-Thinking-2507'
    cfg['model']['timeout'] = 3600; cfg['model']['max_retries'] = 1
    cfg['evaluation']['benchmarks'] = ['gpqa_diamond']
    cfg['evaluation']['generation']['max_tokens'] = 32000
    cfg['evaluation']['concurrency']['num_workers'] = 8
    cfg.setdefault('datasets', {}).setdefault('gpqa_diamond', {}).pop('num_samples', None)
    cfg['evaluation']['output']['results_dir'] = './' + resdir
    cfgf = '/tmp/cfgsw_' + resdir + '.yaml'; yaml.safe_dump(cfg, open(cfgf, 'w'))
    shutil.rmtree(B + '/' + resdir, ignore_errors=True)
    env = dict(os.environ); env['OPENAI_API_KEY'] = 'EMPTY'; env['OPENAI_BASE_URL'] = 'http://localhost:' + port + '/v1'
    subprocess.Popen([FST, 'run_benchmark.py', '--config', cfgf], cwd=B, env=env, stdout=open(logf, 'w'), stderr=subprocess.STDOUT, start_new_session=True)
fire('8001', 'sfi_gpqa_sparse_k4096', '/tmp/sfi_sweep_k4096.log')
fire('8002', 'sfi_gpqa_sparse_k8192', '/tmp/sfi_sweep_k8192.log')
w('FIRED both sweep GPQA'); w('SFI_SWEEP_DONE')
LOG.close()
