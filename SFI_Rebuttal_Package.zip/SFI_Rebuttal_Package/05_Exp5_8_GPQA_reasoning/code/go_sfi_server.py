import os, subprocess, signal, time
REPO = '/mnt/bn/ecom-ai-platform-1/yzc/fst/attention-xx-point-wip-async-prefill-v2'
MAINREPO = '/mnt/bn/ecom-ai-platform-1/yzc/fst/attention-xx-point-main'
TH = '/mnt/bn/ecom-ai-platform-1/yzc/models/Qwen/Qwen3-30B-A3B-Thinking-2507'
FST = '/mnt/bn/ecom-ai-platform-1/yzc/miniconda/envs/fst/bin/python'
LOG = open('/tmp/sfi_orch.log', 'w')
def w(m):
    LOG.write(str(m) + '\n'); LOG.flush()
# controller json from longbench recipe
cj = '{"sink": 8, "k_head": 2048}'
rs = MAINREPO + '/scripts/run_longbench_sparse_gpu0.sh'
if os.path.exists(rs):
    src = open(rs).read(); mi = src.find('VLLM_SPARSE_CONTROLLER_JSON=')
    if mi >= 0:
        q1 = src.find("'", mi); q2 = src.find("'", q1 + 1); cj = src[q1 + 1:q2]
w('cj_len=' + str(len(cj)))
# quick _C check with fst torch (B200/torch2.8)
chk = subprocess.run([FST, '-c', 'import sys; sys.path.insert(0,"' + REPO + '/vllm"); import vllm._C; print("CLOAD_OK")'], capture_output=True, text=True, timeout=60)
w('CLOAD: ' + (chk.stdout.strip() + chk.stderr.strip()[-120:])[:160])
# kill anything on 8001
for p in subprocess.run(['bash', '-c', 'lsof -ti:8001'], capture_output=True, text=True).stdout.split():
    try: os.kill(int(p), 9)
    except Exception: pass
time.sleep(2)
env = dict(os.environ)
env['CUDA_VISIBLE_DEVICES'] = '0'
env['VLLM_SPARSE_CONTROLLER_JSON'] = cj
env['VLLM_SPARSE_DEBUG'] = '0'
env['PYTHONPATH'] = REPO + '/vllm'
subprocess.Popen([FST, '-m', 'vllm.entrypoints.openai.api_server', '--model', TH, '--served-model-name', 'Qwen3-30B-A3B-Thinking-2507', '--port', '8001', '--max-model-len', '40960', '--gpu-memory-utilization', '0.85', '--trust-remote-code', '--enforce-eager'], cwd=REPO, env=env, stdout=open('/tmp/sfi_server.log', 'w'), stderr=subprocess.STDOUT, start_new_session=True)
w('SFI_SERVER_LAUNCHED port8001 gpu0 sparse enforce-eager')
LOG.close()
