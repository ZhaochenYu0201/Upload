import subprocess, os, time, signal, urllib.request, yaml, shutil, json as J, glob
B = '/mnt/bn/ecom-ai-platform-1/yzc/fast-slow/benchmark-eval'
FST = '/mnt/bn/ecom-ai-platform-1/yzc/miniconda/envs/fst/bin/python'
REPO = '/mnt/bn/ecom-ai-platform-1/yzc/fst/attention-xx-point-wip-async-prefill-v2'
TH = '/mnt/bn/ecom-ai-platform-1/yzc/models/Qwen/Qwen3-30B-A3B-Thinking-2507'
MAIN = '/mnt/bn/ecom-ai-platform-1/yzc/fst/attention-xx-point-main/scripts/run_longbench_sparse_gpu0.sh'
LOG = open('/tmp/sfi_phase2.log', 'w')
def w(m):
    LOG.write(str(m) + '\n'); LOG.flush()
# record sweep results
def acc(d):
    m = glob.glob(B + '/' + d + '/*metrics.json')
    if m:
        try: return round(J.load(open(m[0]))['accuracy'] * 100, 2)
        except Exception: return None
    return None
with open('/mnt/bn/ecom-ai-platform-1/yzc/sfi_gpqa_summary.txt', 'a') as f:
    f.write('GPQA sweep: k4096=%s%% k8192=%s%% (k2048=68.69 dense=69.70)\n' % (acc('sfi_gpqa_sparse_k4096'), acc('sfi_gpqa_sparse_k8192')))
# hardkill GPU0,1 (os.killpg, NOT port 8000)
mypg = os.getpgrp()
def pgids(pat):
    out = set()
    for p in subprocess.run(['bash', '-c', 'pgrep -f "' + pat + '"'], capture_output=True, text=True).stdout.split():
        try: out.add(os.getpgid(int(p)))
        except Exception: pass
    return out
killed = []
for pg in pgids('run_benchmark.py'):
    if pg != mypg:
        try: os.killpg(pg, signal.SIGKILL); killed.append('c' + str(pg))
        except Exception: pass
for port in ['8001', '8002']:
    for p in subprocess.run(['bash', '-c', 'lsof -ti:' + port], capture_output=True, text=True).stdout.split():
        try:
            pg = os.getpgid(int(p))
            if pg != mypg: os.killpg(pg, signal.SIGKILL); killed.append('s' + port)
        except Exception: pass
w('killed=' + str(killed)); time.sleep(14)
g = subprocess.run(['bash', '-c', 'nvidia-smi --query-gpu=memory.used --format=csv,noheader -i 0,1'], capture_output=True, text=True).stdout.strip().replace('\n', ' ')
w('gpu01_after_kill=' + g)
src = open(MAIN).read(); mi = src.find('VLLM_SPARSE_CONTROLLER_JSON='); q1 = src.find("'", mi); q2 = src.find("'", q1 + 1)
cjd = J.loads(src[q1 + 1:q2])
d1 = J.loads(J.dumps(cjd)); d1['alpha_fair']['k_head'] = 1024
d2 = J.loads(J.dumps(cjd)); d2['trigger']['enable_sentence_triggers'] = False
def launch(gpu, port, cj):
    env = dict(os.environ); env['CUDA_VISIBLE_DEVICES'] = gpu; env['VLLM_SPARSE_CONTROLLER_JSON'] = cj; env['VLLM_SPARSE_DEBUG'] = '0'; env['PYTHONPATH'] = REPO + '/vllm'
    subprocess.Popen([FST, '-m', 'vllm.entrypoints.openai.api_server', '--model', TH, '--served-model-name', 'Qwen3-30B-A3B-Thinking-2507', '--port', port, '--max-model-len', '40960', '--gpu-memory-utilization', '0.85', '--trust-remote-code', '--enforce-eager'], cwd=REPO, env=env, stdout=open('/tmp/sfi_srv_' + port + '.log', 'w'), stderr=subprocess.STDOUT, start_new_session=True)
launch('0', '8001', J.dumps(d1))
launch('1', '8002', J.dumps(d2))
w('launched k1024@gpu0 trigoff@gpu1')
def health(p):
    try: urllib.request.urlopen('http://localhost:' + p + '/v1/models', timeout=3); return True
    except Exception: return False
for tag, port in [('k1024', '8001'), ('trigoff', '8002')]:
    up = False
    for i in range(120):
        time.sleep(5)
        if health(port): up = True; break
    w('%s_up=%s waited=%ds' % (tag, up, (i + 1) * 5))
def fire(port, resdir, logf):
    cfg = yaml.safe_load(open(B + '/config_30b_sparse.yaml'))
    cfg['model']['base_url'] = 'http://localhost:' + port + '/v1'; cfg['model']['api_key'] = 'EMPTY'; cfg['model']['model_name'] = 'Qwen3-30B-A3B-Thinking-2507'
    cfg['model']['timeout'] = 3600; cfg['model']['max_retries'] = 1
    cfg['evaluation']['benchmarks'] = ['gpqa_diamond']
    cfg['evaluation']['generation']['max_tokens'] = 32000
    cfg['evaluation']['concurrency']['num_workers'] = 8
    cfg.setdefault('datasets', {}).setdefault('gpqa_diamond', {}).pop('num_samples', None)
    cfg['evaluation']['output']['results_dir'] = './' + resdir
    cfgf = '/tmp/cfgp2_' + resdir + '.yaml'; yaml.safe_dump(cfg, open(cfgf, 'w'))
    shutil.rmtree(B + '/' + resdir, ignore_errors=True)
    env = dict(os.environ); env['OPENAI_API_KEY'] = 'EMPTY'; env['OPENAI_BASE_URL'] = 'http://localhost:' + port + '/v1'
    subprocess.Popen([FST, 'run_benchmark.py', '--config', cfgf], cwd=B, env=env, stdout=open(logf, 'w'), stderr=subprocess.STDOUT, start_new_session=True)
fire('8001', 'sfi_gpqa_sparse_k1024', '/tmp/sfi_p2_k1024.log')
fire('8002', 'sfi_gpqa_sparse_trigoff', '/tmp/sfi_p2_trigoff.log')
w('FIRED k1024 + trigoff'); w('PHASE2_DONE')
LOG.close()
