# Self-managing #5/#8 smoke: build server-only -> launch Thinking sparse server -> health -> single /v1 chat test
import subprocess, os, time, json, urllib.request
LOG = open('/tmp/smoke58.log', 'w')
def w(m):
    LOG.write(str(m) + '\n'); LOG.flush()
FST = '/mnt/bn/ecom-ai-platform-1/yzc/miniconda/envs/fst/bin/python'
THINKING = '/mnt/bn/ecom-ai-platform-1/yzc/models/Qwen/Qwen3-30B-A3B-Thinking-2507'
# 1. ensure run_server_only.sh
if not os.path.exists('/tmp/run_server_only.sh'):
    subprocess.run([FST, '/tmp/mk_server_only.py'])
c = open('/tmp/run_server_only.sh').read() if os.path.exists('/tmp/run_server_only.sh') else ''
pred_invoke = any('pred_v1.py' in l and 'timeout' in l for l in c.splitlines())
w('server_only exists=%s lines=%d keepalive=%s pred_invoke=%s' % (bool(c), len(c.splitlines()), 'SERVER_ONLY_READY' in c, pred_invoke))
if not c or 'SERVER_ONLY_READY' not in c or pred_invoke:
    w('SERVER_ONLY_BAD; abort'); LOG.close(); raise SystemExit(1)
# 2. launch server detached
env = dict(os.environ)
env.update({'MODEL_PATH': THINKING, 'MODEL_NAME': 'Qwen3-30B-A3B-Thinking-2507',
            'GPU_DEVICE': '0', 'PORT': '8003', 'K_HEAD': '2016', 'MAX_MODEL_LEN': '40960'})
srv = subprocess.Popen(['bash', '/tmp/run_server_only.sh'], env=env,
                       stdout=open('/tmp/srvonly.log', 'w'), stderr=subprocess.STDOUT, start_new_session=True)
w('server launched pid=%d, waiting health...' % srv.pid)
# 3. health wait up to ~8min
up = False
for i in range(96):
    time.sleep(5)
    try:
        urllib.request.urlopen('http://localhost:8003/v1/models', timeout=3); up = True; break
    except Exception:
        pass
w('server_up=%s waited=%ds' % (up, (i + 1) * 5))
if not up:
    w('SERVER_FAILED tail:'); w(open('/tmp/srvonly.log').read()[-800:]); LOG.close(); raise SystemExit(1)
# 4. single chat test (GPQA-style)
body = json.dumps({"model": "Qwen3-30B-A3B-Thinking-2507",
    "messages": [{"role": "user", "content": "What is 17*23? Think step by step, then answer."}],
    "max_tokens": 2000, "temperature": 0.7}).encode()
try:
    req = urllib.request.Request('http://localhost:8003/v1/chat/completions', data=body, headers={'Content-Type': 'application/json'})
    resp = json.loads(urllib.request.urlopen(req, timeout=120).read())
    txt = resp['choices'][0]['message']['content']
    w('CHAT_OK len=%d tail=%s' % (len(txt), txt[-120:].replace(chr(10), ' ')))
except Exception as e:
    w('CHAT_FAIL %s' % str(e)[:200])
w('SMOKE58_DONE')
LOG.close()
