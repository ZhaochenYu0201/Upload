import subprocess, os, time, yaml, shutil, urllib.request
B = '/mnt/bn/ecom-ai-platform-1/yzc/fast-slow/benchmark-eval'
FST = '/mnt/bn/ecom-ai-platform-1/yzc/miniconda/envs/fst/bin/python'
LOG = open('/tmp/sfi_cleanclients.log', 'w')
def w(m):
    LOG.write(str(m) + '\n'); LOG.flush()
# kill ALL benchmark clients (leave the 2 servers)
subprocess.run(['bash', '-c', 'pkill -9 -f run_benchmark.py; true']); time.sleep(6)
nb = subprocess.run(['bash', '-c', 'pgrep -f run_benchmark|wc -l'], capture_output=True, text=True).stdout.strip()
def health(p):
    try: urllib.request.urlopen('http://localhost:' + p + '/v1/models', timeout=3); return True
    except Exception: return False
w('after_kill nbench=' + nb + ' 8001_up=' + str(health('8001')) + ' 8002_up=' + str(health('8002')))
def fire(port, resdir, logf):
    cfg = yaml.safe_load(open(B + '/config_30b_sparse.yaml'))
    cfg['model']['base_url'] = 'http://localhost:' + port + '/v1'; cfg['model']['api_key'] = 'EMPTY'; cfg['model']['model_name'] = 'Qwen3-30B-A3B-Thinking-2507'
    cfg['model']['timeout'] = 3600; cfg['model']['max_retries'] = 1
    cfg['evaluation']['benchmarks'] = ['gpqa_diamond']
    cfg['evaluation']['generation']['max_tokens'] = 32000
    cfg['evaluation']['concurrency']['num_workers'] = 8
    cfg.setdefault('datasets', {}).setdefault('gpqa_diamond', {}).pop('num_samples', None)
    cfg['evaluation']['output']['results_dir'] = './' + resdir
    cfgf = '/tmp/cfgcc_' + resdir + '.yaml'; yaml.safe_dump(cfg, open(cfgf, 'w'))
    shutil.rmtree(B + '/' + resdir, ignore_errors=True)
    env = dict(os.environ); env['OPENAI_API_KEY'] = 'EMPTY'; env['OPENAI_BASE_URL'] = 'http://localhost:' + port + '/v1'
    subprocess.Popen([FST, 'run_benchmark.py', '--config', cfgf], cwd=B, env=env, stdout=open(logf, 'w'), stderr=subprocess.STDOUT, start_new_session=True)
fire('8001', 'sfi_gpqa_sparse_k4096', '/tmp/sfi_sweep_k4096.log')
fire('8002', 'sfi_gpqa_sparse_k8192', '/tmp/sfi_sweep_k8192.log')
w('FIRED 2 clean clients (8 concurrent each)'); w('CLEAN_DONE')
LOG.close()
