import subprocess, os, time, signal
LOG = open('/tmp/sfi_hardkill.log', 'w')
def w(m):
    LOG.write(str(m) + '\n'); LOG.flush()
mypg = os.getpgrp()
def pgids(pattern):
    pids = subprocess.run(['bash', '-c', 'pgrep -f "' + pattern + '"'], capture_output=True, text=True).stdout.split()
    out = set()
    for p in pids:
        try: out.add(os.getpgid(int(p)))
        except Exception: pass
    return out
killed = []
# benchmark clients
for pg in pgids('run_benchmark.py'):
    if pg != mypg:
        try: os.killpg(pg, signal.SIGKILL); killed.append('client:' + str(pg))
        except Exception as e: w('cli_err %s %s' % (pg, e))
# servers via listening ports
for port in ['8001', '8002', '8000']:
    pids = subprocess.run(['bash', '-c', 'lsof -ti:' + port], capture_output=True, text=True).stdout.split()
    for p in pids:
        try:
            pg = os.getpgid(int(p))
            if pg != mypg: os.killpg(pg, signal.SIGKILL); killed.append('srv%s:%s' % (port, pg))
        except Exception as e: w('srv_err %s' % e)
# vllm engine groups (EngineCore children)
for pg in pgids('vllm'):
    if pg != mypg:
        try: os.killpg(pg, signal.SIGKILL); killed.append('vllm:' + str(pg))
        except Exception: pass
w('killed_pgids=' + str(killed))
time.sleep(14)
g = subprocess.run(['bash', '-c', 'nvidia-smi --query-gpu=memory.used --format=csv,noheader -i 0,1'], capture_output=True, text=True).stdout.strip().replace('\n', ' ')
nb = subprocess.run(['bash', '-c', 'pgrep -f run_benchmark|wc -l'], capture_output=True, text=True).stdout.strip()
ns = subprocess.run(['bash', '-c', 'pgrep -f api_server|wc -l'], capture_output=True, text=True).stdout.strip()
w('AFTER gpu_mem=%s nbench=%s nsrv=%s' % (g, nb, ns))
w('HARDKILL_DONE')
LOG.close()
