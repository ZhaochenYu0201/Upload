import subprocess, os, yaml, shutil, glob, json
B = '/mnt/bn/ecom-ai-platform-1/yzc/fast-slow/benchmark-eval'
FST = '/mnt/bn/ecom-ai-platform-1/yzc/miniconda/envs/fst/bin/python'
LOG = open('/tmp/sfi_bench.log', 'w')
def w(m):
    LOG.write(str(m) + '\n'); LOG.flush()
cfg = yaml.safe_load(open(B + '/config_30b_sparse.yaml'))
cfg['model']['base_url'] = 'http://localhost:8001/v1'
cfg['model']['api_key'] = 'EMPTY'
for k in ['model_name', 'model', 'name']:
    if k in cfg['model']:
        cfg['model'][k] = 'Qwen3-30B-A3B-Thinking-2507'
cfg['model']['model_name'] = 'Qwen3-30B-A3B-Thinking-2507'
cfg['evaluation']['benchmarks'] = ['gpqa_diamond']
cfg['evaluation']['generation']['max_tokens'] = 16000
cfg['evaluation']['concurrency']['num_workers'] = 2
cfg.setdefault('datasets', {}).setdefault('gpqa_diamond', {})['num_samples'] = 3
cfg['evaluation']['output']['results_dir'] = './sfi_gpqa_smoke'
yaml.safe_dump(cfg, open('/tmp/cfg_sfi.yaml', 'w'))
shutil.rmtree(B + '/sfi_gpqa_smoke', ignore_errors=True)
env = dict(os.environ); env['OPENAI_API_KEY'] = 'EMPTY'; env['OPENAI_BASE_URL'] = 'http://localhost:8001/v1'
w('running gpqa smoke (3 samples)...')
r = subprocess.run([FST, 'run_benchmark.py', '--config', '/tmp/cfg_sfi.yaml'], cwd=B, env=env, capture_output=True, text=True, timeout=2400)
w('rc=' + str(r.returncode) + ' err=' + r.stderr.strip()[-150:])
ms = sorted(glob.glob(B + '/sfi_gpqa_smoke/*metrics.json'))
if ms:
    m = json.load(open(ms[-1]))
    w('METRICS acc=' + str(m.get('accuracy')) + ' correct=' + str(m.get('correct')) + ' total=' + str(m.get('total')))
    rj = sorted(glob.glob(B + '/sfi_gpqa_smoke/*results.jsonl'))
    if rj:
        r0 = [json.loads(l) for l in open(rj[-1])][0]
        w('mo_len=' + str(len(r0.get('model_output') or '')) + ' err=' + str((r0.get('metadata') or {}).get('error', 'none'))[:40])
w('SFI_BENCH_DONE')
LOG.close()
