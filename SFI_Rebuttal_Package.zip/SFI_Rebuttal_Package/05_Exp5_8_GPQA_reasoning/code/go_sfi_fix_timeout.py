import subprocess, os, yaml, shutil, time
B = '/mnt/bn/ecom-ai-platform-1/yzc/fast-slow/benchmark-eval'
FST = '/mnt/bn/ecom-ai-platform-1/yzc/miniconda/envs/fst/bin/python'
LOG = open('/tmp/sfi_fixto.log', 'w')
def w(m):
    LOG.write(str(m) + '\n'); LOG.flush()
# 1) find how the client/timeout is configured
cc = subprocess.run(['bash', '-c', 'grep -rniE "timeout|max_retries|AsyncOpenAI|OpenAI\\(|base_url" ' + B + ' --include=*.py 2>/dev/null | grep -iE "timeout|OpenAI\\(|max_retries" | head -12'], capture_output=True, text=True).stdout
w('CODE_CLIENT:\n' + cc[:800])
# 2) kill current benchmark clients (leave servers running)
ks = subprocess.run(['bash', '-c', 'pgrep -f run_benchmark.py'], capture_output=True, text=True).stdout.split()
for p in ks:
    try: os.kill(int(p), 9)
    except Exception: pass
w('killed_bench_pids=' + str(ks)); time.sleep(3)
# 3) relaunch both with safer params + best-effort timeout fields
def launch(port, resdir, logf):
    cfg = yaml.safe_load(open(B + '/config_30b_sparse.yaml'))
    cfg['model']['base_url'] = 'http://localhost:' + port + '/v1'
    cfg['model']['api_key'] = 'EMPTY'; cfg['model']['model_name'] = 'Qwen3-30B-A3B-Thinking-2507'
    for tf in ['timeout', 'request_timeout', 'client_timeout', 'api_timeout']:
        cfg['model'][tf] = 3600
    cfg['evaluation']['benchmarks'] = ['gpqa_diamond']
    cfg['evaluation']['generation']['max_tokens'] = 20000
    cfg['evaluation']['concurrency']['num_workers'] = 2
    if 'timeout' in cfg['evaluation'].get('concurrency', {}):
        cfg['evaluation']['concurrency']['timeout'] = 3600
    cfg.setdefault('datasets', {}).setdefault('gpqa_diamond', {}).pop('num_samples', None)
    cfg['evaluation']['output']['results_dir'] = './' + resdir
    cfgf = '/tmp/cfg_' + resdir + '.yaml'; yaml.safe_dump(cfg, open(cfgf, 'w'))
    shutil.rmtree(B + '/' + resdir, ignore_errors=True)
    env = dict(os.environ); env['OPENAI_API_KEY'] = 'EMPTY'; env['OPENAI_BASE_URL'] = 'http://localhost:' + port + '/v1'
    subprocess.Popen([FST, 'run_benchmark.py', '--config', cfgf], cwd=B, env=env, stdout=open(logf, 'w'), stderr=subprocess.STDOUT, start_new_session=True)
launch('8001', 'sfi_gpqa_sparse_k2048', '/tmp/sfi_full_sparse.log')
launch('8002', 'sfi_gpqa_dense', '/tmp/sfi_full_dense.log')
w('RELAUNCHED both num_workers2 max_tokens20000 timeout3600-besteffort')
w('SFI_FIXTO_DONE')
LOG.close()
