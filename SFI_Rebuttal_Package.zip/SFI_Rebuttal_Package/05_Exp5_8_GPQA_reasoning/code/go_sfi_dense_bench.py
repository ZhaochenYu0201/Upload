import subprocess, os, yaml, shutil, urllib.request, time
B = '/mnt/bn/ecom-ai-platform-1/yzc/fast-slow/benchmark-eval'
FST = '/mnt/bn/ecom-ai-platform-1/yzc/miniconda/envs/fst/bin/python'
LOG = open('/tmp/sfi_densebench_orch.log', 'w')
def w(m):
    LOG.write(str(m) + '\n'); LOG.flush()
up = False
for i in range(70):
    try:
        urllib.request.urlopen('http://localhost:8002/v1/models', timeout=3); up = True; break
    except Exception:
        time.sleep(5)
w('dense_up=' + str(up) + ' waited=' + str((i + 1) * 5))
if up:
    cfg = yaml.safe_load(open(B + '/config_30b_sparse.yaml'))
    cfg['model']['base_url'] = 'http://localhost:8002/v1'; cfg['model']['api_key'] = 'EMPTY'; cfg['model']['model_name'] = 'Qwen3-30B-A3B-Thinking-2507'
    cfg['evaluation']['benchmarks'] = ['gpqa_diamond']
    cfg['evaluation']['generation']['max_tokens'] = 32000
    cfg['evaluation']['concurrency']['num_workers'] = 4
    cfg.setdefault('datasets', {}).setdefault('gpqa_diamond', {}).pop('num_samples', None)
    cfg['evaluation']['output']['results_dir'] = './sfi_gpqa_dense'
    yaml.safe_dump(cfg, open('/tmp/cfg_dense_full.yaml', 'w'))
    shutil.rmtree(B + '/sfi_gpqa_dense', ignore_errors=True)
    env = dict(os.environ); env['OPENAI_API_KEY'] = 'EMPTY'; env['OPENAI_BASE_URL'] = 'http://localhost:8002/v1'
    subprocess.Popen([FST, 'run_benchmark.py', '--config', '/tmp/cfg_dense_full.yaml'], cwd=B, env=env, stdout=open('/tmp/sfi_full_dense.log', 'w'), stderr=subprocess.STDOUT, start_new_session=True)
    w('FULL_DENSE_GPQA_FIRED port8002 all-samples')
else:
    w('dense NOT up; tail:' + (open('/tmp/sfi_dense_server.log').read()[-280:] if os.path.exists('/tmp/sfi_dense_server.log') else 'nolog'))
w('DENSEBENCH_ORCH_DONE')
LOG.close()
