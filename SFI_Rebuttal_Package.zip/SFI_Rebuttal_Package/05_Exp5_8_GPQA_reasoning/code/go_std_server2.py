import os, subprocess, time, json, urllib.request, signal
LOG = open('/tmp/stdsrv2_orch.log', 'w')
def w(m):
    LOG.write(str(m) + '\n'); LOG.flush()
FST_PY = '/mnt/bn/ecom-ai-platform-1/yzc/miniconda/envs/fst/bin/python'
REPO = '/mnt/bn/ecom-ai-platform-1/yzc/fst/attention-xx-point-wip-async-prefill-v2'
TH = '/mnt/bn/ecom-ai-platform-1/yzc/models/Qwen/Qwen3-30B-A3B-Thinking-2507'
geom = open('/mnt/bn/ecom-ai-platform-1/yzc/sfi1/attention-xx-point/utils/selector_pipeline_ext.py').read().count('_wf = __expf')
w('geom=' + str(geom))
cj = None
for rs in [REPO + '/scripts/run_longbench_sparse_gpu0.sh', '/mnt/bn/ecom-ai-platform-1/yzc/fst/attention-xx-point-main/scripts/run_longbench_sparse_gpu0.sh']:
    if os.path.exists(rs):
        src = open(rs).read(); mi = src.find('VLLM_SPARSE_CONTROLLER_JSON=')
        if mi >= 0:
            q1 = src.find("'", mi); q2 = src.find("'", q1 + 1); cj = src[q1 + 1:q2]
            w('cj_from=' + os.path.basename(os.path.dirname(os.path.dirname(rs))) + ' len=' + str(len(cj))); break
if not cj:
    cj = '{"sink": 8, "k_head": 2016}'
for pid in subprocess.run(['bash', '-c', 'lsof -ti:8000'], capture_output=True, text=True).stdout.split():
    try: os.kill(int(pid), signal.SIGKILL)
    except Exception: pass
for pat in ['vllm.entrypoints', 'api_server']:
    for pid in subprocess.run(['pgrep', '-f', pat], capture_output=True, text=True).stdout.split():
        try: os.kill(int(pid), signal.SIGKILL)
        except Exception: pass
time.sleep(5)
env = dict(os.environ)
env['CUDA_VISIBLE_DEVICES'] = '0'; env['VLLM_SPARSE_CONTROLLER_JSON'] = cj
env['VLLM_SPARSE_DEBUG'] = '0'; env['VLLM_SPARSE_ALPHA_DEBUG'] = '0'
env['PYTHONPATH'] = REPO + '/vllm:' + env.get('PYTHONPATH', '')
cmd = [FST_PY, '-m', 'vllm.entrypoints.openai.api_server', '--model', TH, '--served-model-name', 'Qwen3-30B-A3B-Thinking-2507', '--port', '8000', '--max-model-len', '40960', '--gpu-memory-utilization', '0.85', '--trust-remote-code']
subprocess.Popen(cmd, cwd=REPO, env=env, stdout=open('/tmp/stdsrv2.log', 'w'), stderr=subprocess.STDOUT, start_new_session=True)
w('launched v2 standard server port8000')
up = False
for i in range(150):
    time.sleep(5)
    try:
        urllib.request.urlopen('http://localhost:8000/v1/models', timeout=3); up = True; break
    except Exception:
        pass
sl = open('/tmp/stdsrv2.log').read() if os.path.exists('/tmp/stdsrv2.log') else ''
w('up=' + str(up) + ' waited=' + str((i + 1) * 5) + ' sparse=' + str('Sparse controller' in sl))
if not up:
    w('FAIL tail=' + sl[-400:]); LOG.close(); raise SystemExit(1)
body = json.dumps({"model": "Qwen3-30B-A3B-Thinking-2507", "messages": [{"role": "user", "content": "What is 17*23? Think step by step, then state the answer."}], "max_tokens": 4000, "temperature": 0.6}).encode()
try:
    req = urllib.request.Request('http://localhost:8000/v1/chat/completions', data=body, headers={'Content-Type': 'application/json'})
    resp = json.loads(urllib.request.urlopen(req, timeout=400).read())
    txt = resp['choices'][0]['message']['content']
    w('REQ_OK len=' + str(len(txt)) + ' tail=' + txt[-90:].replace(chr(10), ' '))
except Exception as e:
    w('REQ_FAIL ' + str(e)[:140])
try:
    urllib.request.urlopen('http://localhost:8000/v1/models', timeout=4); w('survived=True')
except Exception:
    w('survived=False')
w('STD2_DONE'); LOG.close()
