import os, subprocess, signal, time
REPO = '/mnt/bn/ecom-ai-platform-1/yzc/fst/attention-xx-point-wip-async-prefill-v2'
TH = '/mnt/bn/ecom-ai-platform-1/yzc/models/Qwen/Qwen3-30B-A3B-Thinking-2507'
MAIN = '/mnt/bn/ecom-ai-platform-1/yzc/fst/attention-xx-point-main/scripts/run_longbench_sparse_gpu0.sh'
rs = REPO + '/scripts/run_longbench_sparse_gpu0.sh'
src = open(rs).read() if os.path.exists(rs) else open(MAIN).read()
mi = src.find('VLLM_SPARSE_CONTROLLER_JSON=')
q1 = src.find("'", mi); q2 = src.find("'", q1 + 1); cj = src[q1 + 1:q2]
for p in subprocess.run(['bash', '-c', 'lsof -ti:8000'], capture_output=True, text=True).stdout.split():
    try: os.kill(int(p), 9)
    except Exception: pass
time.sleep(3)
env = dict(os.environ)
env['CUDA_VISIBLE_DEVICES'] = '0'; env['VLLM_SPARSE_CONTROLLER_JSON'] = cj
env['VLLM_SPARSE_DEBUG'] = '0'; env['PYTHONPATH'] = REPO + '/vllm'
FST = '/mnt/bn/ecom-ai-platform-1/yzc/miniconda/envs/fst/bin/python'
subprocess.Popen([FST, '-m', 'vllm.entrypoints.openai.api_server', '--model', TH, '--served-model-name', 'Qwen3-30B-A3B-Thinking-2507', '--port', '8000', '--max-model-len', '32768', '--gpu-memory-utilization', '0.80', '--trust-remote-code', '--enforce-eager'], cwd=REPO, env=env, stdout=open('/tmp/stdsrv2.log', 'w'), stderr=subprocess.STDOUT, start_new_session=True)
open('/tmp/launched2.txt', 'w').write('launched cj_len=' + str(len(cj)))
