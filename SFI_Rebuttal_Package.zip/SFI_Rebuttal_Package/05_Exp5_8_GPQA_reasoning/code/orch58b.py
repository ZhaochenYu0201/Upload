import os, subprocess, time, urllib.request, glob, json, yaml, shutil, signal
LOG = open('/tmp/orch58b.log', 'w')
def w(m):
    LOG.write(str(m) + '\n'); LOG.flush()
FST = '/mnt/bn/ecom-ai-platform-1/yzc/miniconda/envs/fst/bin/python'
TH = '/mnt/bn/ecom-ai-platform-1/yzc/models/Qwen/Qwen3-30B-A3B-Thinking-2507'
B = '/mnt/bn/ecom-ai-platform-1/yzc/fast-slow/benchmark-eval'
f = '/tmp/run_server_only.sh'
s = open(f).read()
for v in ['"--api-key","token-abc123",', '"--api-key", "token-abc123",', '"--api-key","token-abc123"', '"--full-cuda-graph",', '"--full-cuda-graph"', ]:
    s = s.replace(v, '')
w('fullcudagraph_in_script=%s' % ('full-cuda-graph' in s))
if '--gpu-memory-utilization' not in s:
    for anc in ['"--trust-remote-code",', '"${PORT}",', '"--served-model-name",', ',"--port",']:
        if anc in s:
            s = s.replace(anc, anc + '"--gpu-memory-utilization","0.55",', 1)
            break
open(f, 'w').write(s)
import re as _re
_mm = _re.search(r'gpu-memory-utilization","([0-9.]+)', s)
w('apikey_in_script=%s gmutil=%s' % ('--api-key' in s, _mm.group(1) if _mm else 'MISSING'))
try:
    pids = subprocess.run(['bash', '-c', 'lsof -ti:8013'], capture_output=True, text=True).stdout.split()
    for p in pids:
        try: os.kill(int(p), signal.SIGKILL)
        except Exception: pass
    w('killed 8013 pids=%s' % pids)
except Exception as e:
    w('killerr %s' % e)
time.sleep(6)
env = dict(os.environ)
env.update({'MODEL_PATH': TH, 'MODEL_NAME': 'Qwen3-30B-A3B-Thinking-2507', 'GPU_DEVICE': '0', 'PORT': '8013', 'K_HEAD': '2016', 'MAX_MODEL_LEN': '16000', 'GPU_MEM_UTIL': '0.5', 'MAX_NUM_SEQS': '2'})
subprocess.Popen(['bash', f], env=env, stdout=open('/tmp/srv7.log', 'w'), stderr=subprocess.STDOUT, start_new_session=True)
w('server relaunched no-auth, waiting...')
def health():
    try:
        urllib.request.urlopen('http://localhost:8013/v1/models', timeout=3); return True
    except Exception:
        return False
up = False
for i in range(110):
    time.sleep(5)
    if health():
        up = True; break
w('server_up=%s waited=%ds' % (up, (i + 1) * 5))
if not up:
    w('FAIL tail:'); w(open('/tmp/srv7.log').read()[-600:]); LOG.close(); raise SystemExit(1)
cfg = yaml.safe_load(open(B + '/config_30b_sparse.yaml'))
cfg['model']['base_url'] = 'http://localhost:8013/v1'
cfg['model']['api_key'] = 'token-abc123'
cfg['evaluation']['benchmarks'] = ['gpqa_diamond']
cfg['evaluation']['generation']['max_tokens'] = 8000
cfg['evaluation']['concurrency']['num_workers'] = 1
cfg.setdefault('datasets', {}).setdefault('gpqa_diamond', {})['num_samples'] = 2
cfg['evaluation']['output']['results_dir'] = './sparse_30b_gpqa_smoke'
yaml.safe_dump(cfg, open('/tmp/cfg58.yaml', 'w'))
shutil.rmtree(B + '/sparse_30b_gpqa_smoke', ignore_errors=True)
env2 = dict(os.environ); env2['OPENAI_API_KEY'] = 'token-abc123'
w('running benchmark...')
r = subprocess.run([FST, 'run_benchmark.py', '--config', '/tmp/cfg58.yaml'], cwd=B, env=env2, capture_output=True, text=True, timeout=2400)
w('bench_rc=%d' % r.returncode)
ms = sorted(glob.glob(B + '/sparse_30b_gpqa_smoke/*metrics.json'))
if ms:
    met = json.load(open(ms[-1]))
    w('METRICS acc=%s correct=%s total=%s' % (met.get('accuracy'), met.get('correct'), met.get('total')))
    rj = sorted(glob.glob(B + '/sparse_30b_gpqa_smoke/*results.jsonl'))[-1]
    r0 = [json.loads(l) for l in open(rj)][0]
    w('mo_len=%d err=%s' % (len(r0.get('model_output') or ''), (r0.get('metadata') or {}).get('error', 'none')))
w('server_still_up=%s ORCH58B_DONE' % health())
LOG.close()
