import subprocess, os, yaml, shutil, time
B = '/mnt/bn/ecom-ai-platform-1/yzc/fast-slow/benchmark-eval'
FST = '/mnt/bn/ecom-ai-platform-1/yzc/miniconda/envs/fst/bin/python'
LOG = open('/tmp/sfi_relaunch.log', 'w')
def w(m):
    LOG.write(str(m) + '\n'); LOG.flush()
ks = subprocess.run(['bash', '-c', 'pgrep -f run_benchmark.py'], capture_output=True, text=True).stdout.split()
for p in ks:
    try: os.kill(int(p), 9)
    except Exception: pass
w('killed=' + str(ks)); time.sleep(3)
def launch(port, resdir, logf):
    cfg = yaml.safe_load(open(B + '/config_30b_sparse.yaml'))
    cfg['model']['base_url'] = 'http://localhost:' + port + '/v1'
    cfg['model']['api_key'] = 'EMPTY'; cfg['model']['model_name'] = 'Qwen3-30B-A3B-Thinking-2507'
    cfg['model']['timeout'] = 3600
    cfg['model']['max_retries'] = 1
    cfg['evaluation']['benchmarks'] = ['gpqa_diamond']
    cfg['evaluation']['generation']['max_tokens'] = 32000
    cfg['evaluation']['concurrency']['num_workers'] = 4
    cfg.setdefault('datasets', {}).setdefault('gpqa_diamond', {}).pop('num_samples', None)
    cfg['evaluation']['output']['results_dir'] = './' + resdir
    cfgf = '/tmp/cfgopt_' + resdir + '.yaml'; yaml.safe_dump(cfg, open(cfgf, 'w'))
    shutil.rmtree(B + '/' + resdir, ignore_errors=True)
    env = dict(os.environ); env['OPENAI_API_KEY'] = 'EMPTY'; env['OPENAI_BASE_URL'] = 'http://localhost:' + port + '/v1'
    subprocess.Popen([FST, 'run_benchmark.py', '--config', cfgf], cwd=B, env=env, stdout=open(logf, 'w'), stderr=subprocess.STDOUT, start_new_session=True)
launch('8001', 'sfi_gpqa_sparse_k2048', '/tmp/sfi_full_sparse.log')
launch('8002', 'sfi_gpqa_dense', '/tmp/sfi_full_dense.log')
w('RELAUNCHED_OPTIMAL num_workers4 max_tokens32000 timeout3600 max_retries1')
w('SFI_RELAUNCH_DONE')
LOG.close()
