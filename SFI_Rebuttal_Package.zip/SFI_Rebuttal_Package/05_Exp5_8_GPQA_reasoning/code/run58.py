import yaml, subprocess, os
B = '/mnt/bn/ecom-ai-platform-1/yzc/fast-slow/benchmark-eval'
FST = '/mnt/bn/ecom-ai-platform-1/yzc/miniconda/envs/fst/bin/python'
cfg = yaml.safe_load(open(B + '/config_30b_sparse.yaml'))
cfg['model']['base_url'] = 'http://localhost:8013/v1'
cfg['model']['api_key'] = 'token-abc123'
cfg['evaluation']['benchmarks'] = ['gpqa_diamond']
cfg['evaluation']['generation']['max_tokens'] = 16384
cfg['evaluation']['concurrency']['num_workers'] = 1
cfg.setdefault('datasets', {}).setdefault('gpqa_diamond', {})['num_samples'] = 2
cfg['evaluation']['output']['results_dir'] = './sparse_30b_gpqa_smoke'
yaml.safe_dump(cfg, open('/tmp/cfg58.yaml', 'w'))
env = dict(os.environ)
env['OPENAI_API_KEY'] = 'token-abc123'
env['OPENAI_BASE_URL'] = 'http://localhost:8013/v1'
subprocess.Popen([FST, 'run_benchmark.py', '--config', '/tmp/cfg58.yaml'], cwd=B, env=env,
                 stdout=open('/tmp/gpqa_smoke.log', 'w'), stderr=subprocess.STDOUT, start_new_session=True)
print('RUN58_LAUNCHED bench=%s base=%s key=%s' % (cfg['evaluation']['benchmarks'], cfg['model']['base_url'], cfg['model']['api_key']))
