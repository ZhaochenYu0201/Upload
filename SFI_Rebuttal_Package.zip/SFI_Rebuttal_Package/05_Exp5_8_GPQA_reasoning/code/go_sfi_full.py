import subprocess, os, yaml, shutil
B = '/mnt/bn/ecom-ai-platform-1/yzc/fast-slow/benchmark-eval'
FST = '/mnt/bn/ecom-ai-platform-1/yzc/miniconda/envs/fst/bin/python'
REPO = '/mnt/bn/ecom-ai-platform-1/yzc/fst/attention-xx-point-wip-async-prefill-v2'
TH = '/mnt/bn/ecom-ai-platform-1/yzc/models/Qwen/Qwen3-30B-A3B-Thinking-2507'
LOG = open('/tmp/sfi_full_orch.log', 'w')
def w(m):
    LOG.write(str(m) + '\n'); LOG.flush()
# 1) FULL SPARSE GPQA against port 8001 (all samples)
cfg = yaml.safe_load(open(B + '/config_30b_sparse.yaml'))
cfg['model']['base_url'] = 'http://localhost:8001/v1'; cfg['model']['api_key'] = 'EMPTY'; cfg['model']['model_name'] = 'Qwen3-30B-A3B-Thinking-2507'
cfg['evaluation']['benchmarks'] = ['gpqa_diamond']
cfg['evaluation']['generation']['max_tokens'] = 32000
cfg['evaluation']['concurrency']['num_workers'] = 4
cfg.setdefault('datasets', {}).setdefault('gpqa_diamond', {}).pop('num_samples', None)
cfg['evaluation']['output']['results_dir'] = './sfi_gpqa_sparse_k2048'
yaml.safe_dump(cfg, open('/tmp/cfg_sparse_full.yaml', 'w'))
shutil.rmtree(B + '/sfi_gpqa_sparse_k2048', ignore_errors=True)
env = dict(os.environ); env['OPENAI_API_KEY'] = 'EMPTY'; env['OPENAI_BASE_URL'] = 'http://localhost:8001/v1'
subprocess.Popen([FST, 'run_benchmark.py', '--config', '/tmp/cfg_sparse_full.yaml'], cwd=B, env=env, stdout=open('/tmp/sfi_full_sparse.log', 'w'), stderr=subprocess.STDOUT, start_new_session=True)
w('FULL_SPARSE_GPQA_FIRED port8001 all-samples num_workers4')
# 2) DENSE reference server on GPU1 port 8002 (NO VLLM_SPARSE_CONTROLLER_JSON = dense)
for p in subprocess.run(['bash', '-c', 'lsof -ti:8002'], capture_output=True, text=True).stdout.split():
    try: os.kill(int(p), 9)
    except Exception: pass
denv = dict(os.environ)
denv['CUDA_VISIBLE_DEVICES'] = '1'
denv['PYTHONPATH'] = REPO + '/vllm'
denv.pop('VLLM_SPARSE_CONTROLLER_JSON', None)
subprocess.Popen([FST, '-m', 'vllm.entrypoints.openai.api_server', '--model', TH, '--served-model-name', 'Qwen3-30B-A3B-Thinking-2507', '--port', '8002', '--max-model-len', '40960', '--gpu-memory-utilization', '0.85', '--trust-remote-code', '--enforce-eager'], cwd=REPO, env=denv, stdout=open('/tmp/sfi_dense_server.log', 'w'), stderr=subprocess.STDOUT, start_new_session=True)
w('DENSE_SERVER_LAUNCHED gpu1 port8002 no-sparse')
w('SFI_FULL_ORCH_DONE')
LOG.close()
