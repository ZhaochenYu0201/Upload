# SFI (Slow–Fast Inference) — Rebuttal Experiments Package

This package collects **all rebuttal experiments** for the SFI sparse-attention method:
the code used to run each experiment, the final result files, and per-experiment
documentation (what / setting / how-to-run / result / conclusion).

SFI applies **token-level compact + recent sparse attention** on top of vLLM 0.19 +
vendored FlashAttention (FA3 SM80/SM90, FA4 SM100/B200), with native CUDA-graph replay.
The rebuttal goal is to show the method is **near-lossless on accuracy while delivering
a large decode speed-up**, and that it **generalizes** across selector designs, model
families, context distances, and hard reasoning tasks.

---

## TL;DR — headline results

| Axis | Benchmark / model | Dense | Sparse | Gap |
|---|---|---|---|---|
| **Long-context accuracy** (Table 8) | LongBench-V1, Qwen3-30B-Instruct, γ=0.5 | — | **≈44.67** | lossless band |
| | LongBench-v2 (λ=0.005, compensated) | ~34.9 | **35.4** | lossless |
| **Selector/fusion design** (Table 9) | LongBench-V1, Qwen3-30B-Instruct | — | topk 45.13 / ref 44.72 / kn 44.39 / pos 44.58 / **v2-geo 45.74** | all near baseline |
| **Cross-family** (#10) | LongBench-V1 21-task, Phi-3.5-MoE | **43.70** | **43.03** @ k12288 | **-0.67** (~noise) |
| **Distance robustness** (#11) | LongBench-V1, per-example bins | (per-bin) | (per-bin) | **-0.6 ~ -1.5, flat vs length** |
| **Hard reasoning** (#5/#8) | GPQA-diamond, Qwen3-30B-**Thinking** | **69.70%** | k2048 68.69 / k4096 71.21 / k8192 69.70 | **±1.5% (near-lossless, robust to budget)** |
| **Throughput** (#12/#14) | decode @ 262k context | 1× | **2.04×** | — |

**Overall conclusion:** SFI is **near-lossless** across long-context retrieval, hard
multi-step reasoning, multiple model families, and all context-distance bins, while
giving a **2.04× decode speed-up** at 262k context. Accuracy is robust to the sparse
budget (`k_head`): larger budget monotonically closes the (already small) gap to dense.

---

## Folder layout

```
SFI_Rebuttal_Package/
├── README.md                          <- this file (master overview + all results + conclusions)
├── 01_Table8_gamma_lambda_sweep/      <- γ (trigger) / λ (fusion) hyperparameter sweep
├── 02_Table9_selector_ablation/       <- selector & fusion design ablation (5 designs)
├── 03_Exp10_crossfamily_Phi/          <- cross-family port to Phi-3.5-MoE + budget curve
├── 04_Exp11_distance_binned/          <- gap vs context-length (post-hoc, 0-GPU)
├── 05_Exp5_8_GPQA_reasoning/          <- hard reasoning: GPQA on Qwen3-30B-Thinking (NEW)
├── 06_throughput/                     <- decode throughput / speed-up (#12/#14)
└── _raw_result_logs/                  <- raw running result log (phi_crossfamily_results.txt)
```

Each `0X_*/` folder has its own `README.md`, a `code/` sub-folder with the scripts used,
and a `results/` sub-folder with the result files that were small enough to bundle.

---

## Shared experimental setup

- **Runtime:** vLLM 0.19 + vendored FlashAttention; SFI sparse patch injected via
  `sitecustomize.py` when `VLLM_SPARSE_*` env vars are set.
- **Sparse controller:** configured through `VLLM_SPARSE_CONTROLLER_JSON`. Key fields:
  `k_min`, `sink`, `recent`, `trigger{refresh_interval, enable_sentence_triggers}`,
  and `alpha_fair{k_head, soft_alpha, cross_head_alpha, ...}`. The **sparse budget knob
  is `alpha_fair.k_head`** (NOT a top-level `k_head`).
- **Hardware:** FA4 / SM100 runs on **NVIDIA B200**; FA3 / SM90 runs on H100. B200 needs
  CUDA 12.8 / torch ≥2.7 (the `fst` conda env ships torch 2.8.0+cu128).
- **Accuracy harnesses:** LongBench-V1/v2 (`fast-slow/attention-xx-point/LongBench`,
  `eval.py`); GPQA/MMLU via `fast-slow/benchmark-eval` (`run_benchmark.py`).
- **Dense reference:** `VLLM_SPARSE_FA4_DENSE_GATEWAY=1` (or stock vLLM) with no controller JSON.

See each experiment's README for the exact command, env vars, and config used.

---

## Per-experiment index

| # | Experiment | Model | Benchmark | Headline |
|---|---|---|---|---|
| 01 | Table 8 — γ/λ sweep | Qwen3-30B-Instruct | LongBench-V1 + v2 | γ=0.5 / λ=0.005 optimal; lossless |
| 02 | Table 9 — selector ablation | Qwen3-30B-Instruct | LongBench-V1 | v2 forward-KL (geometric) = 45.74 |
| 03 | #10 — cross-family | Phi-3.5-MoE | LongBench-V1 21-task | k12288 = 43.03 vs dense 43.70 (-0.67) |
| 04 | #11 — distance-binned | Qwen3-30B-Instruct | LongBench-V1 | gap flat -0.6~-1.5 across distance |
| 05 | #5/#8 — GPQA reasoning | Qwen3-30B-**Thinking** | GPQA-diamond | sparse 68.69~71.21 vs dense 69.70 |
| 06 | #12/#14 — throughput | Qwen3-30B | decode @ 262k | 2.04× |

---

## Status / caveats (honesty notes)

- **#5 activation sweep** has 4 confirmed points (dense / k2048 / k4096 / k8192). A 5th
  point **k1024** (more sparse) and the **#8 trigger-off ablation** were set up but **did
  not complete** (the launch failed silently under a throttled remote shell); they are
  *not* in this package. The 4 confirmed points already establish the "near-lossless,
  budget-robust" conclusion.
- **MMLU** for the Thinking model was planned but not run.
- The **bulky raw per-sample prediction files** (`results*.jsonl`, multi-MB each) live on
  the remote box under `/mnt/bn/ecom-ai-platform-1/yzc/fast-slow/...` and are **referenced,
  not bundled** (too large to transfer over the remote shell). The per-experiment READMEs
  give their exact remote paths. The bundled `results/` contain the small metrics/summary
  files; all numbers are reproduced in the READMEs.

_Packaged from the SFI working tree; raw running log preserved in `_raw_result_logs/phi_crossfamily_results.txt`._
