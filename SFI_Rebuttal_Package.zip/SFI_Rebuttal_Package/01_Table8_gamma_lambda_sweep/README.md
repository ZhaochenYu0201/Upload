# Exp Table 8 (#2) — γ (trigger) / λ (fusion) hyperparameter sweep

## What this experiment is

The base hyperparameter sweep for the SFI sparse controller on long-context accuracy:
the **trigger threshold γ** and the **fusion weight λ** that combine the "compact" and
"recent" attention scores. Establishes the operating point used by the other experiments
and shows SFI is lossless at the chosen setting.

- Models / data: **Qwen3-30B-A3B-Instruct** on **LongBench-V1** (per-task overall) and
  **LongBench-v2** (with the official `compensated` scoring).
- Hardware: FA4 / SM100 (B200) and FA3 / SM90 (H100) runners.

## Headline result

- **γ sweep (LongBench-V1):** the chosen **γ = 0.5** gives overall **≈ 44.67**, the
  arithmetic / reverse-KL default fusion baseline (this is the same baseline referenced by
  Table 9). γ=0.5 sits in the lossless band vs dense.
- **λ sweep (LongBench-v2):** overall accuracy peaks at **λ = 0.005**; with the official
  LongBench-v2 `compensated` scoring this gives **35.4**, which is **≥ the dense reference
  (~34.9 compensated)** — i.e. **lossless** (the apparent "loss" at raw scoring was a
  scoring-protocol artifact: ~7–8% of samples never emit the `"The correct answer is (X)"`
  string and are scored 0 by `extract_answer` unless `compensated=True`; dense and sparse
  are affected equally, and the dense "target" 34.8 is itself a compensated number).

**Conclusion:** at the operating point γ=0.5 / λ=0.005, SFI is **lossless** on both
LongBench-V1 and LongBench-v2. The λ peak is broad/shallow (changes are within ~1%
run-to-run noise); the real accuracy alignment came from using the **same (compensated)
scoring protocol** for dense and sparse.

## Experimental setup

- Sparse controller via `VLLM_SPARSE_CONTROLLER_JSON` with `gamma` (trigger) and the
  fusion `lambda` (`alpha_fair` λ params) swept; `k_head` at the tuned Qwen budget.
- True dense reference: `VLLM_SPARSE_FA4_DENSE_GATEWAY=1` with **no** controller JSON
  (do **not** approximate dense with a huge `k_head`).
- LongBench-v2 `compensated` recompute: `result_enhanced.py` / `result.py` hardcode
  `compensated=False`; flip to `True` (`sed 's/compensated = False/compensated = True/'`)
  to get the official compensated score, then restore.

## How to run

Launch scripts in `code/`:
- `run_longbenchv2_fa4_sparse_b200.sh` — B200 FA4 LongBench-v2 sparse runner
- `run_longbenchv2_fa3_sparse_h100.sh` — H100 FA3 LongBench-v2 sparse runner

Sweep γ / λ by editing the `VLLM_SPARSE_CONTROLLER_JSON` (`gamma`, fusion `lambda`) the
runner exports; score with the LongBench-v2 harness (compensated).

## Result files

Numbers are reproduced above. Raw LongBench-v2 prediction dirs are on the remote box under
`…/fast-slow/attention-xx-point/LongBench*/results_*` (referenced, not bundled — multi-MB).

> Note: the precise per-γ / per-λ grid points were logged on the remote runs; the
> load-bearing facts (γ=0.5 ≈ 44.67; λ=0.005 → 35.4 compensated = lossless) are recorded
> here and in the handoff notes. If a fuller grid table is needed, re-score the remote
> `results_*` dirs with the runners above.
