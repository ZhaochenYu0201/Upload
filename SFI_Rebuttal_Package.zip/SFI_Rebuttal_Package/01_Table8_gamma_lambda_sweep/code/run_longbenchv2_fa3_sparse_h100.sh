#!/usr/bin/env bash
# =============================================================================
# run_longbenchv2_fa3_sparse_h100.sh
# -----------------------------------------------------------------------------
# H100/SM90/FA3 fork of run_longbenchv2_fa4_sparse_b200.sh. Same LongBench-v2
# (503 MCQ, contexts up to 262144) sparse run, end to end, but on a single
# H100 with FA3-native (compact_recent) instead of FA4-SM100/CuTe.
#
# ONLY arch-coupled lines differ from the B200 driver (acc stays comparable):
#   --backend fa3 (was fa4-sm100); --attention-config flash_attn_version:3 (was 4);
#   VLLM_FLASH_ATTN_VERSION=3; TORCH_CUDA_ARCH_LIST=9.0; EXTDIR=h100; GPU_DEVICE=0.
# Everything else (model, selector JSON, max-model-len, MAX_NUM_SEQS=2,
# client pred.py + result_enhanced.py) is IDENTICAL to the B200 run on purpose.
# Per user: do NOT pre-reduce concurrency; handle OOM reactively if it occurs.
#
# USAGE (ON the H100 box, webshell job 960712):  bash run_longbenchv2_fa3_sparse_h100.sh
# Env overrides: GPU_DEVICE(0) K_HEAD(4096) COMPACT_BLOCKS(288) PREFILL_LAST_N(16)
#   PORT(8013) MAX_MODEL_LEN(262144) GPU_MEM_UTIL(0.85) N_PROC(1) DETACH(0) RUN_EVAL(1)
# =============================================================================
set -uo pipefail

SFI="${SFI:-/mnt/bn/ecom-ai-platform-1/yzc/sfi1/attention-xx-point}"
CONDA="${CONDA:-/mnt/bn/ecom-ai-platform-1/yzc/miniconda}"
ENVN="${ENVN:-fst_v2}"                  # FA3-native sparse runtime env (server)
CLIENT_ENV="${CLIENT_ENV:-fst}"         # LongBench client/eval env (datasets/tiktoken/jieba)
MODEL_PATH="${MODEL_PATH:-/mnt/bn/ecom-ai-platform-1/yzc/models/Qwen/Qwen3-4B-Instruct-2507}"
MODEL_NAME="${MODEL_NAME:-Qwen3-4B-Instruct-2507}"
LONGBENCH="${LONGBENCH:-/mnt/bn/ecom-ai-platform-1/yzc/fast-slow/attention-xx-point/LongBench}"
EXTDIR="${EXTDIR:-/tmp/torch_ext_h100_lbsparse}"   # H100-only ext cache (avoid B200 .so pollution)

GPU_DEVICE="${GPU_DEVICE:-0}"           # single visible H100
PORT="${PORT:-8013}"
K_HEAD="${K_HEAD:-4096}"
COMPACT_BLOCKS="${COMPACT_BLOCKS:-288}"  # x16 (=4608) must hold sink+effective_k_head(~4144)
SINK="${SINK:-4}"
RECENT="${RECENT:-256}"
REFRESH="${REFRESH:-32}"
SOFT_ALPHA="${SOFT_ALPHA:-0}"
CROSS_HEAD_ALPHA="${CROSS_HEAD_ALPHA:-0}"
LAMBDA_CLIP="${LAMBDA_CLIP:-0.0005}"
PREFILL_LAST_N="${PREFILL_LAST_N:-16}"
MAX_MODEL_LEN="${MAX_MODEL_LEN:-262144}"
GPU_MEM_UTIL="${GPU_MEM_UTIL:-0.85}"
MAX_NUM_SEQS="${MAX_NUM_SEQS:-2}"        # KEEP = B200 (do not pre-reduce; handle OOM reactively)
CAPTURE_BUDGET="${CAPTURE_BUDGET:-8589934592}"
N_PROC="${N_PROC:-1}"
SAVE_DIR="${SAVE_DIR:-results_fa3_sparse_longbenchv2}"
RUN_EVAL="${RUN_EVAL:-1}"
PRED_TIMEOUT="${PRED_TIMEOUT:-21600}"
DETACH="${DETACH:-0}"

P="${CONDA}/envs/${ENVN}/bin/python"
PRED_PY="${CONDA}/envs/${CLIENT_ENV}/bin/python"
TAG="${TAG:-lbv2fa3}"
ST="/tmp/${TAG}_status.txt"
SRV_LOG="/tmp/${TAG}_server.log"
MEM_LOG="/tmp/${TAG}_mem.log"
log(){ echo "$(date -u +%H:%M:%S) $*" | tee -a "$ST"; }

if [ "${DETACH}" = "1" ] && [ "${_LBV2_DETACHED:-0}" != "1" ]; then
  _LBV2_DETACHED=1 setsid nohup bash "$0" </dev/null >"/tmp/${TAG}_driver.log" 2>&1 &
  echo "detached pid=$! (status: $ST)"; exit 0
fi

: > "$ST"
log "START v2 FA3/H100 gpu=$GPU_DEVICE port=$PORT k_head=$K_HEAD compact=$COMPACT_BLOCKS sink=$SINK recent=$RECENT refresh=$REFRESH soft=$SOFT_ALPHA cross=$CROSS_HEAD_ALPHA lambda=$LAMBDA_CLIP prefill_last_n=$PREFILL_LAST_N maxlen=$MAX_MODEL_LEN seqs=$MAX_NUM_SEQS"
[ -x "$P" ] || { log "FATAL server python not found: $P"; exit 1; }
[ -x "$PRED_PY" ] || { log "FATAL client python not found: $PRED_PY"; exit 1; }

SERVER_PY="/tmp/${TAG}_server.py"
cat > "$SERVER_PY" <<PYSERVER
import os, sys, json as _json
from pathlib import Path
SFI = "${SFI}"
MP = "${MODEL_PATH}"
sys.path[:0] = [f"{SFI}/third_party_upstreams/vllm-project-flash-attention", SFI]
import benchmarks.bench_sm80_mixed_page_one_shot_graph_e2e as B
argv = ["--mode","sparse","--preset","bs2long-cap128","--backend","fa3","--full-cuda-graph",
        "--model",MP,"--gpu-mem-util","0.4","--producer-mode","full-open-gt1","--prefill-last-n","${PREFILL_LAST_N}",
        "--no-defer-bootstrap-producer","--compact-blocks-per-slot","${COMPACT_BLOCKS}",
        "--batch-size","2","--max-new-tokens","128","--output","/tmp/${TAG}_r.jsonl","--summary-output","/tmp/${TAG}_s.json"]
args = B.parse_args(argv)
env = B._build_gate_d_sparse_env(args, route_trace_path=Path("/tmp/${TAG}_route.jsonl"))
os.environ.update({k: str(v) for k, v in env.items()})
_cj = _json.loads(os.environ.get("VLLM_SPARSE_CONTROLLER_JSON", "{}"))
_cj["tau"] = 1.0; _cj["k_min"] = 32; _cj["k_max"] = None
_cj["sink"] = ${SINK}; _cj["recent"] = ${RECENT}; _cj["refresh_interval"] = ${REFRESH}
_cj["alpha_fair"] = {
    "k_head": ${K_HEAD}, "soft_alpha": ${SOFT_ALPHA}, "cross_head_alpha": ${CROSS_HEAD_ALPHA},
    "cross_head_temperature": 2.0, "cross_head_power": 0.0,
    "prior_pos_power": 1.8, "prior_pos_eta": 0.4,
    "lambda_tail_kappa": 0.0, "lambda_tail_pivot": 0.7,
    "lambda_clip_single": ${LAMBDA_CLIP}, "lambda_clip_multi": ${LAMBDA_CLIP},
}
_cj["adaptive"] = {"enabled": False}
_t = dict(_cj.get("trigger") or {}); _t["refresh_interval"] = ${REFRESH}; _t["enable_sentence_triggers"] = True
_cj["trigger"] = _t
os.environ["VLLM_SPARSE_CONTROLLER_JSON"] = _json.dumps(_cj, sort_keys=True)
print("V2_SPARSE_CONFIG=" + os.environ["VLLM_SPARSE_CONTROLLER_JSON"][:900], flush=True)
os.environ["TORCH_EXTENSIONS_DIR"] = "${EXTDIR}"
os.environ["CUDA_VISIBLE_DEVICES"] = "${GPU_DEVICE}"
os.environ.setdefault("VLLM_SPARSE_SELECTOR_FIXED_K", "1")
os.environ["VLLM_SPARSE_CAPTURE_ARENA_BUDGET_BYTES"] = "${CAPTURE_BUDGET}"
os.environ["VLLM_WORKER_MULTIPROC_METHOD"] = "spawn"
os.environ.setdefault("VLLM_NO_USAGE_REPORT", "1"); os.environ.setdefault("CPUINFO_NO_DMI", "1")
cmd = [sys.executable,"-m","vllm.entrypoints.openai.api_server","--model",MP,"--served-model-name",MP,
       "--port","${PORT}","--api-key","token-abc123","--trust-remote-code",
       "--attention-config",'{"backend":"FLASH_ATTN","flash_attn_version":3}',
       "--tensor-parallel-size","1","--dtype","bfloat16","--max-model-len","${MAX_MODEL_LEN}",
       "--gpu-memory-utilization","${GPU_MEM_UTIL}","--max-num-seqs","${MAX_NUM_SEQS}",
       "--max-num-partial-prefills","1","--max-num-batched-tokens","16384","--enable-chunked-prefill"]
print("EXEC " + " ".join(cmd), flush=True)
os.execvp(cmd[0], cmd)
PYSERVER

pkill -f "[p]red.py" 2>/dev/null || true
lsof -ti:"$PORT" 2>/dev/null | xargs -r kill -9 2>/dev/null || true
rm -f "/tmp/${TAG}_server.pid" "$MEM_LOG" 2>/dev/null || true
sleep 2

cd "$SFI"
source "$CONDA/etc/profile.d/conda.sh"; conda activate "$ENVN"
export PATH="$CONDA/envs/$ENVN/bin:$PATH"
export PYTHONPATH="$SFI/third_party_upstreams/vllm-project-flash-attention:$SFI"
export CUDA_VISIBLE_DEVICES="$GPU_DEVICE"
export TORCH_EXTENSIONS_DIR="$EXTDIR"
export TORCH_CUDA_ARCH_LIST=9.0
export VLLM_FLASH_ATTN_VERSION=3
mkdir -p "$EXTDIR"

log "precompile selector exts -> $EXTDIR"
"$P" - <<'PY' 2>>"$ST" || { log "FATAL ext precompile failed"; exit 1; }
from utils.bounds_kernel_ext import _require_ext as rb
from utils.selector_pipeline_ext import _require_ext as rp
rb(); rp(); print("precompile ok")
PY

setsid bash -c "while true; do echo \"\$(date -u +%H:%M:%S) \$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i $GPU_DEVICE 2>/dev/null)\"; sleep 5; done" > "$MEM_LOG" 2>&1 < /dev/null &
echo $! > "/tmp/${TAG}_mem.pid"
log "launch sparse server (port $PORT)"
setsid "$P" "$SERVER_PY" > "$SRV_LOG" 2>&1 < /dev/null &
echo $! > "/tmp/${TAG}_server.pid"
s=0
SPID=$(cat "/tmp/${TAG}_server.pid" 2>/dev/null)
for i in $(seq 1 240); do
  curl -sf -m3 -H "Authorization: Bearer token-abc123" "http://127.0.0.1:$PORT/health" >/dev/null 2>&1 && s=1 || s=0
  [ "$s" = 1 ] && break
  if [ -n "$SPID" ] && ! kill -0 "$SPID" 2>/dev/null; then log "server process $SPID DIED early (fail-fast); see $SRV_LOG"; break; fi
  sleep 5
done
log "health=$s after $((i*5))s"
grep -iE "V2_SPARSE_CONFIG|ValueError|smaller than selector|OutOfMemory|Error" "$SRV_LOG" 2>/dev/null | head -4 | tee -a "$ST"
[ "$s" = 1 ] || { log "FATAL server not healthy; see $SRV_LOG"; exit 1; }
for i in $(seq 1 120); do
  code=$(curl -s -o /dev/null -w "%{http_code}" -H "Authorization: Bearer token-abc123" -H "Content-Type: application/json" \
    -X POST "http://127.0.0.1:$PORT/v1/chat/completions" \
    -d "{\"model\":\"$MODEL_PATH\",\"messages\":[{\"role\":\"user\",\"content\":\"ping\"}],\"max_tokens\":1,\"temperature\":0.0}")
  [ "$code" = "200" ] && break; sleep 5
done
log "engine ready (probe http=$code)"

if [ "${SERVER_ONLY:-0}" = "1" ]; then
  touch "/tmp/${TAG}_ready"
  log "SERVER_ONLY=1: server healthy and left running (pid=$(cat /tmp/${TAG}_server.pid 2>/dev/null)); skip pred.py + teardown"
  exit 0
fi

# ---- step 2: LongBench-v2 pred.py (run from $LONGBENCH so config/ + dataset resolve) ----
cd "$LONGBENCH"
unset SSL_CERT_FILE ALL_PROXY all_proxy HTTP_PROXY http_proxy HTTPS_PROXY https_proxy
export NO_PROXY="127.0.0.1,localhost"
export HF_DATASETS_OFFLINE=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 HF_HUB_DISABLE_TELEMETRY=1
rm -rf "$SAVE_DIR/$MODEL_NAME.jsonl" 2>/dev/null || true
log "run pred.py (LongBench-v2) -> $SAVE_DIR (timeout ${PRED_TIMEOUT}s, client=$CLIENT_ENV)"
timeout "$PRED_TIMEOUT" "$PRED_PY" pred.py --model "$MODEL_NAME" --url "http://127.0.0.1:$PORT/v1" \
  --api_key token-abc123 --n_proc "$N_PROC" --save_dir "$SAVE_DIR" > "/tmp/${TAG}_pred.out" 2>&1
log "RESULT lines=$(wc -l < "$SAVE_DIR/$MODEL_NAME.jsonl" 2>/dev/null || echo 0)"
log "MEM min/max/last(MiB)=$(awk '{print $2}' "$MEM_LOG" 2>/dev/null | sort -n | awk 'NR==1{mn=$1}{mx=$1;last=$1}END{print mn"/"mx"/"last}')"
grep -iE "OutOfMemory|EngineDeadError|illegal memory|ValueError" "$SRV_LOG" 2>/dev/null | tail -3 | tee -a "$ST"

# ---- step 3: score (result_enhanced.py) ----
if [ "$RUN_EVAL" = "1" ]; then
  log "score with result_enhanced.py"
  ( cd "$LONGBENCH" && "$PRED_PY" result_enhanced.py --result_dir "$SAVE_DIR" --detailed 2>&1 ) | tee -a "$ST"
fi

# ---- teardown ----
SP=$(cat "/tmp/${TAG}_server.pid" 2>/dev/null); [ -n "$SP" ] && kill -9 -"$SP" 2>/dev/null || true
lsof -ti:"$PORT" 2>/dev/null | xargs -r kill -9 2>/dev/null || true
kill "$(cat "/tmp/${TAG}_mem.pid" 2>/dev/null)" 2>/dev/null || true
log "DONE (result: $LONGBENCH/$SAVE_DIR/$MODEL_NAME.jsonl ; route: /tmp/${TAG}_route.jsonl)"
