# 读取 #10 (K12288) + #11 (Qwen dense V1) 结果

在 **970992** 的终端里执行。把输出的两行 `overall=` 复制回 Claude。

---

## 方案 1（推荐，单条命令，一次出两个数）

整条复制（是**一行**，别手动加换行）：

```
/mnt/bn/ecom-ai-platform-1/yzc/miniconda/envs/fst/bin/python -c "import subprocess,os,json;os.chdir('/mnt/bn/ecom-ai-platform-1/yzc/fast-slow/attention-xx-point/LongBench');P='/mnt/bn/ecom-ai-platform-1/yzc/miniconda/envs/fst/bin/python';subprocess.run([P,'LongBench/eval.py','--model','Phi-3.5-MoE-instruct','--f','results_phi_k12288'],capture_output=True);subprocess.run([P,'LongBench/eval.py','--model','Qwen3-30B-A3B-Instruct-2507','--f','results_qwen_dense_v1'],capture_output=True);d=json.load(open('results_phi_k12288/Phi-3.5-MoE-instruct/result.json'));e=json.load(open('results_qwen_dense_v1/Qwen3-30B-A3B-Instruct-2507/result.json'));print('K12288_sparse_10 overall=%.2f N=%d'%(sum(d.values())/len(d),len(d)));print('QwenDense_11 overall=%.2f N=%d'%(sum(e.values())/len(e),len(e)))"
```

预期输出：

```
K12288_sparse_10 overall=XX.XX N=21
QwenDense_11 overall=XX.XX N=21
```

---

## 方案 2（如果方案 1 还报错，分步来）

**第 1 步**——先进目录（这一条单独执行）：

```
cd /mnt/bn/ecom-ai-platform-1/yzc/fast-slow/attention-xx-point/LongBench
```

**第 2 步**——跑 K12288 评分（单独执行，约 30 秒，会打印一堆分数）：

```
/mnt/bn/ecom-ai-platform-1/yzc/miniconda/envs/fst/bin/python LongBench/eval.py --model Phi-3.5-MoE-instruct --f results_phi_k12288
```

**第 3 步**——跑 Qwen dense 评分（单独执行）：

```
/mnt/bn/ecom-ai-platform-1/yzc/miniconda/envs/fst/bin/python LongBench/eval.py --model Qwen3-30B-A3B-Instruct-2507 --f results_qwen_dense_v1
```

**第 4 步**——打印两个总分（单独执行）：

```
/mnt/bn/ecom-ai-platform-1/yzc/miniconda/envs/fst/bin/python -c "import json;d=json.load(open('results_phi_k12288/Phi-3.5-MoE-instruct/result.json'));e=json.load(open('results_qwen_dense_v1/Qwen3-30B-A3B-Instruct-2507/result.json'));print('K12288=%.2f QwenDense=%.2f'%(sum(d.values())/len(d),sum(e.values())/len(e)))"
```

方案 2 里第 2、3 步会直接打印每个任务的分数 + 平均，你把这些整段贴回来给我也行，我来汇总。

---

## 说明

- 第一行 `K12288` = #10 跨族 Phi sparse 的 K_HEAD=8192→12288 收口点（看预算曲线是否饱和在 ~42.5）
- 第二行 `QwenDense` = #11 距离分桶的 dense baseline
- 已知曲线：DENSE 43.70 | k2016 39.47 | k4096 40.72 | k6144 41.99 | k8192 42.44
