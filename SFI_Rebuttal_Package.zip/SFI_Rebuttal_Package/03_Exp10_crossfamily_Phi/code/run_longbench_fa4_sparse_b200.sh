#!/usr/bin/env bash
# =============================================================================
# run_longbench_fa4_sparse_b200.sh
# -----------------------------------------------------------------------------
# Run the LongBench accuracy experiment with SPARSE FA4 (compact_recent) on a
# single B200 / SM100 GPU, end to end: precompile -> launch sparse vLLM server
# -> run LongBench pred_v1 -> score with eval.py.
#
# Encodes the *validated* selector config (verified 0/750 degenerate, matching
# dense): gpu0 alpha_fair tuning + k_head=4032 (selected ~4140 after 112-tile
# alignment) + small lambda_clip(0.01) + compact_blocks_per_slot=288 (must hold
# sink+effective_k_head) + sink=4 + recent=256 + refresh_interval=64.
#
# Backend: FA4-SM100 one-shot-graph route (--backend fa4-sm100 --full-cuda-graph).
# Carries the deferred-capture-scratch LRU leak fix (flat GPU memory under serving).
#
# DEGENERATION (verified clean, no extra sparse overhead): a request whose
# context length kv_len <= sink + effective_k_head + recent (~4400) has no
# sparsity benefit and degenerates to a DENSE full-KV row -- the alpha_fair
# selector / key_norms pack / compact-arena bind / capture-refresh are all
# structurally skipped; the row is plain dense FA4. Raising k_head 1536->4032
# raises this threshold ~1824->~4400 (more short requests go dense, intended).
#
# USAGE (ON the B200 box):
#   bash run_longbench_fa4_sparse_b200.sh
# Override anything via env, e.g.:
#   GPU_DEVICE=1 K_HEAD=4032 RUN_EVAL=1 bash run_longbench_fa4_sparse_b200.sh
# =============================================================================
set -uo pipefail

# ---- knobs (env-overridable) ----
SFI="${SFI:-/mnt/bn/ecom-ai-platform-1/yzc/sfi1/attention-xx-point}"
CONDA="${CONDA:-/mnt/bn/ecom-ai-platform-1/yzc/miniconda}"
ENVN="${ENVN:-fst_v2}"
MODEL_PATH="${MODEL_PATH:-/mnt/bn/ecom-ai-platform-1/yzc/models/Qwen/Qwen3-4B-Instruct-2507}"
MODEL_NAME="${MODEL_NAME:-Qwen3-4B-Instruct-2507}"
LONGBENCH="${LONGBENCH:-/mnt/bn/ecom-ai-platform-1/yzc/fast-slow/attention-xx-point/LongBench}"
EXTDIR="${EXTDIR:-/tmp/torch_ext_b200_lbsparse}"

GPU_DEVICE="${GPU_DEVICE:-1}"          # physical B200 GPU index (0 or 1; 2-7 belong to others)
PORT="${PORT:-8010}"
K_HEAD="${K_HEAD:-4032}"               # selected tokens/head; MUST be 112-aligned-friendly (4032=36*112)
COMPACT_BLOCKS="${COMPACT_BLOCKS:-288}"  # physical compact pages/slot; x16 must be >= sink+effective_k_head
SINK="${SINK:-4}"
RECENT="${RECENT:-256}"
REFRESH="${REFRESH:-64}"
SOFT_ALPHA="${SOFT_ALPHA:-1.0}"
CROSS_HEAD_ALPHA="${CROSS_HEAD_ALPHA:-0.85}"
LAMBDA_CLIP="${LAMBDA_CLIP:-0.01}"     # lambda_clip_single/multi (kept small: sensitive param)
MAX_NEW_TOKENS="${MAX_NEW_TOKENS:-128}"
MAX_MODEL_LEN="${MAX_MODEL_LEN:-131072}"
GPU_MEM_UTIL="${GPU_MEM_UTIL:-0.6}"
MAX_NUM_SEQS="${MAX_NUM_SEQS:-4}"
SAVE_DIR="${SAVE_DIR:-results_fa4_sparse_longbench}"
RUN_EVAL="${RUN_EVAL:-1}"
PRED_TIMEOUT="${PRED_TIMEOUT:-3600}"
DETACH="${DETACH:-0}"

P="${CONDA}/envs/${ENVN}/bin/python"
TAG="lbfa4"
ST="/tmp/${TAG}_status.txt"
SRV_LOG="/tmp/${TAG}_server.log"
MEM_LOG="/tmp/${TAG}_mem.log"
log(){ echo "$(date -u +%H:%M:%S) $*" | tee -a "$ST"; }

# self-detach so it survives a flaky shell, if DETACH=1
if [ "${DETACH}" = "1" ] && [ "${_LBFA4_DETACHED:-0}" != "1" ]; then
  _LBFA4_DETACHED=1 setsid nohup bash "$0" </dev/null >"/tmp/${TAG}_driver.log" 2>&1 &
  echo "detached pid=$! (status: $ST)"; exit 0
fi

: > "$ST"
log "START gpu=$GPU_DEVICE port=$PORT k_head=$K_HEAD compact_blocks=$COMPACT_BLOCKS sink=$SINK recent=$RECENT refresh=$REFRESH"
[ -x "$P" ] || { log "FATAL python not found: $P"; exit 1; }

# ---- inline FA4-SM100 sparse server: build the bench's FA4-SM100 env, then inject
#      the validated gpu0 selector config over the controller JSON. ----
SERVER_PY="/tmp/${TAG}_server.py"
cat > "$SERVER_PY" <<PYSERVER
import os, sys, json as _json
from pathlib import Path
SFI = "${SFI}"
MP = "${MODEL_PATH}"
sys.path[:0] = [f"{SFI}/third_party_upstreams/vllm-project-flash-attention", SFI]
import benchmarks.bench_sm80_mixed_page_one_shot_graph_e2e as B
argv = ["--mode","sparse","--preset","bs2long-cap128","--backend","fa4-sm100","--full-cuda-graph",
        "--model",MP,"--gpu-mem-util","0.95","--producer-mode","full-open-gt1","--prefill-last-n","2",
        "--no-defer-bootstrap-producer","--compact-blocks-per-slot","${COMPACT_BLOCKS}",
        "--batch-size","2","--max-new-tokens","${MAX_NEW_TOKENS}",
        "--output","/tmp/${TAG}_r.jsonl","--summary-output","/tmp/${TAG}_s.json"]
args = B.parse_args(argv)
env = B._build_gate_d_sparse_env(args, route_trace_path=Path("/tmp/${TAG}_route.jsonl"))
os.environ.update({k: str(v) for k, v in env.items()})
# Inject the validated gpu0 LongBench-accuracy selector config (keep FA4-SM100 structural fields).
_cj = _json.loads(os.environ.get("VLLM_SPARSE_CONTROLLER_JSON", "{}"))
_cj["tau"] = 1.0; _cj["k_min"] = 32; _cj["k_max"] = None
_cj["sink"] = ${SINK}; _cj["recent"] = ${RECENT}; _cj["refresh_interval"] = ${REFRESH}
_cj["alpha_fair"] = {
    "k_head": ${K_HEAD}, "soft_alpha": ${SOFT_ALPHA}, "cross_head_alpha": ${CROSS_HEAD_ALPHA},
    "cross_head_temperature": 2.0, "cross_head_power": 0.0,
    "prior_pos_power": 1.8, "prior_pos_eta": 0.4,
    "lambda_tail_kappa": 0.0, "lambda_tail_pivot": 0.7,
    "lambda_clip_single": ${LAMBDA_CLIP}, "lambda_clip_multi": ${LAMBDA_CLIP},
}
_cj["adaptive"] = {"enabled": False}
_t = dict(_cj.get("trigger") or {}); _t["refresh_interval"] = ${REFRESH}; _t["enable_sentence_triggers"] = True
_cj["trigger"] = _t
os.environ["VLLM_SPARSE_CONTROLLER_JSON"] = _json.dumps(_cj, sort_keys=True)
print("SPARSE_CONFIG=" + os.environ["VLLM_SPARSE_CONTROLLER_JSON"][:900], flush=True)
os.environ["TORCH_EXTENSIONS_DIR"] = "${EXTDIR}"
os.environ["CUDA_VISIBLE_DEVICES"] = "${GPU_DEVICE}"
os.environ.setdefault("VLLM_SPARSE_SELECTOR_FIXED_K", "1")
os.environ["VLLM_SPARSE_CAPTURE_ARENA_BUDGET_BYTES"] = "8589934592"
os.environ["VLLM_WORKER_MULTIPROC_METHOD"] = "spawn"
os.environ.setdefault("VLLM_NO_USAGE_REPORT", "1"); os.environ.setdefault("CPUINFO_NO_DMI", "1")
cmd = [sys.executable,"-m","vllm.entrypoints.openai.api_server","--model",MP,"--served-model-name",MP,
       "--port","${PORT}","--api-key","token-abc123","--trust-remote-code",
       "--attention-config",'{"backend":"FLASH_ATTN","flash_attn_version":4}',
       "--tensor-parallel-size","1","--dtype","bfloat16","--max-model-len","${MAX_MODEL_LEN}",
       "--gpu-memory-utilization","${GPU_MEM_UTIL}","--max-num-seqs","${MAX_NUM_SEQS}",
       "--max-num-partial-prefills","1","--max-num-batched-tokens","16384","--enable-chunked-prefill"]
print("EXEC " + " ".join(cmd), flush=True)
os.execvp(cmd[0], cmd)
PYSERVER

# ---- clean prior instances on this port ----
pkill -f "[p]red_v1.py" 2>/dev/null || true
lsof -ti:"$PORT" 2>/dev/null | xargs -r kill -9 2>/dev/null || true
rm -f "/tmp/${TAG}_server.pid" "$MEM_LOG" 2>/dev/null || true
sleep 2

# ---- env ----
cd "$SFI"
source "$CONDA/etc/profile.d/conda.sh"; conda activate "$ENVN"
export PATH="$CONDA/envs/$ENVN/bin:$PATH"
export PYTHONPATH="$SFI/third_party_upstreams/vllm-project-flash-attention:$SFI"
export CUDA_VISIBLE_DEVICES="$GPU_DEVICE"
export TORCH_EXTENSIONS_DIR="$EXTDIR"
export TORCH_CUDA_ARCH_LIST=10.0
export VLLM_FLASH_ATTN_VERSION=4
mkdir -p "$EXTDIR"

# ---- step 0: precompile selector exts (into the isolated B200 ext dir) ----
log "precompile selector exts -> $EXTDIR"
"$P" - <<'PY' 2>>"$ST" || { log "FATAL ext precompile failed"; exit 1; }
from utils.bounds_kernel_ext import _require_ext as rb
from utils.selector_pipeline_ext import _require_ext as rp
rb(); rp(); print("precompile ok")
PY

# ---- step 1: launch sparse server ----
setsid bash -c "while true; do echo \"\$(date -u +%H:%M:%S) \$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i $GPU_DEVICE 2>/dev/null)\"; sleep 5; done" > "$MEM_LOG" 2>&1 < /dev/null &
echo $! > "/tmp/${TAG}_mem.pid"
log "launch sparse server (port $PORT)"
setsid "$P" "$SERVER_PY" > "$SRV_LOG" 2>&1 < /dev/null &
echo $! > "/tmp/${TAG}_server.pid"
s=0
for i in $(seq 1 180); do
  curl -sf -m3 -H "Authorization: Bearer token-abc123" "http://127.0.0.1:$PORT/health" >/dev/null 2>&1 && s=1 || s=0
  [ "$s" = 1 ] && break; sleep 5
done
log "health=$s after $((i*5))s"
grep -iE "SPARSE_CONFIG|ValueError|smaller than selector|OutOfMemory" "$SRV_LOG" 2>/dev/null | head -3 | tee -a "$ST"
[ "$s" = 1 ] || { log "FATAL server did not become healthy; see $SRV_LOG"; exit 1; }
# inference-engine readiness probe (health!=ready)
for i in $(seq 1 120); do
  code=$(curl -s -o /dev/null -w "%{http_code}" -H "Authorization: Bearer token-abc123" -H "Content-Type: application/json" \
    -X POST "http://127.0.0.1:$PORT/v1/chat/completions" \
    -d "{\"model\":\"$MODEL_PATH\",\"messages\":[{\"role\":\"user\",\"content\":\"ping\"}],\"max_tokens\":1,\"temperature\":0.0}")
  [ "$code" = "200" ] && break; sleep 5
done
log "engine ready (probe http=$code)"

# ---- step 2: LongBench pred ----
cd "$LONGBENCH"
unset SSL_CERT_FILE ALL_PROXY all_proxy HTTP_PROXY http_proxy HTTPS_PROXY https_proxy
export NO_PROXY="127.0.0.1,localhost"
export HF_DATASETS_OFFLINE=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 HF_HUB_DISABLE_TELEMETRY=1
rm -rf "$SAVE_DIR/$MODEL_NAME" 2>/dev/null || true
log "run pred_v1.py -> $SAVE_DIR (timeout ${PRED_TIMEOUT}s)"
timeout "$PRED_TIMEOUT" "$P" pred_v1.py --model "$MODEL_NAME" --port "$PORT" --save_dir "$SAVE_DIR" -n 1 > "/tmp/${TAG}_pred.out" 2>&1
for t in narrativeqa qasper multifieldqa_en hotpotqa; do
  log "RESULT $t lines=$(wc -l < "$SAVE_DIR/$MODEL_NAME/$t.jsonl" 2>/dev/null || echo 0)"
done
log "MEM min/max/last(MiB)=$(awk '{print $2}' "$MEM_LOG" 2>/dev/null | sort -n | awk 'NR==1{mn=$1}{mx=$1;last=$1}END{print mn"/"mx"/"last}')"
grep -iE "OutOfMemory|EngineDeadError|illegal memory|ValueError" "$SRV_LOG" 2>/dev/null | tail -3 | tee -a "$ST"

# ---- step 3: score ----
if [ "$RUN_EVAL" = "1" ]; then
  # eval.py lives in the NESTED LongBench/LongBench/ dir and needs jieba/rouge/fuzzywuzzy,
  # which the 'fst' env has but the sparse-runtime env (fst_v2) does NOT. Use EVAL_PY (fst).
  EVAL_PY="${EVAL_PY:-$CONDA/envs/fst/bin/python}"
  log "score with $LONGBENCH/LongBench/eval.py (via $EVAL_PY)"
  ( cd "$LONGBENCH" && "$EVAL_PY" LongBench/eval.py --model "$MODEL_NAME" --f "$SAVE_DIR" 2>&1 ) | tee -a "$ST"
fi

# ---- teardown server (free the GPU) ----
SP=$(cat "/tmp/${TAG}_server.pid" 2>/dev/null); [ -n "$SP" ] && kill -9 -"$SP" 2>/dev/null || true
lsof -ti:"$PORT" 2>/dev/null | xargs -r kill -9 2>/dev/null || true
kill "$(cat "/tmp/${TAG}_mem.pid" 2>/dev/null)" 2>/dev/null || true
log "DONE (results: $LONGBENCH/$SAVE_DIR/$MODEL_NAME ; route trace: /tmp/${TAG}_route.jsonl)"
