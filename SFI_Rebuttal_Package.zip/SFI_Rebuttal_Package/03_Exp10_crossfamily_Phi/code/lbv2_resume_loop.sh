#!/usr/bin/env bash
set -uo pipefail
if [ "${_LOOP_DETACHED:-0}" != "1" ]; then
  _LOOP_DETACHED=1 setsid nohup bash "$0" </dev/null >/tmp/lbv2_loop_driver.log 2>&1 &
  echo "loop detached pid=$!"; exit 0
fi
LB=/mnt/bn/ecom-ai-platform-1/yzc/fast-slow/attention-xx-point/LongBench
SAVE=results_fa4_sparse_lbv2_bsgt1
TARGET=500
PORT=10451
LOG=/tmp/lbv2_loop.log
SCRIPT=/tmp/run_longbenchv2_fa4_sparse_b200.sh
PY_FST=/mnt/bn/ecom-ai-platform-1/yzc/miniconda/envs/fst/bin/python
hc(){ curl -sf -m3 -H "Authorization: Bearer token-abc123" "http://127.0.0.1:$PORT/health" >/dev/null 2>&1; }
echo "LOOP_START $(date -u +%H:%M:%S)" >> "$LOG"
last=-1; lastchg=0; i=0
while [ "$i" -lt 240 ]; do
  i=$((i+1))
  d=$(cat "$LB/$SAVE"/*.jsonl 2>/dev/null | wc -l)
  if [ "$d" -ne "$last" ]; then last=$d; lastchg=$i; fi
  echo "TICK $i done=$d $(date -u +%H:%M:%S)" >> "$LOG"
  if [ "$d" -ge "$TARGET" ]; then echo "TARGET_REACHED $d" >> "$LOG"; break; fi
  if hc && pgrep -f "[p]red.py" >/dev/null 2>&1; then sleep 90; continue; fi
  if [ $((i - lastchg)) -ge 10 ]; then echo "STALLED no-progress at $d" >> "$LOG"; break; fi
  echo "RELAUNCH at done=$d $(date -u +%H:%M:%S)" >> "$LOG"
  GPU_DEVICE=1 MAX_NUM_SEQS=8 N_PROC=8 GPU_MEM_UTIL=0.78 SAVE_DIR="$SAVE" DETACH=0 RUN_EVAL=0 bash "$SCRIPT" >> "/tmp/lbv2_round_${i}.log" 2>&1
  sleep 15
done
final=$(cat "$LB/$SAVE"/*.jsonl 2>/dev/null | wc -l)
echo "LOOP_END done=$final $(date -u +%H:%M:%S)" >> "$LOG"
cd "$LB" && "$PY_FST" result_enhanced.py --result_dir "$SAVE" --detailed >> "$LOG" 2>&1 || echo "SCORE_FAILED" >> "$LOG"
echo "ALL_DONE $(date -u +%H:%M:%S)" >> "$LOG"
