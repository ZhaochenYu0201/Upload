"""Fire 2 staggered concurrent long-prompt requests at the FA4 sparse server to
force a mixed prefill+compact forward (the original n_proc=2 crash scenario).
Stdlib only (urllib). Run from the repo dir so benchmarks/ prompts resolve."""
import urllib.request, json, threading, time

MP = "/mnt/bn/ecom-ai-platform-1/yzc/models/Qwen/Qwen3-4B-Instruct-2507"
BASE = "benchmarks/"
PROMPTS = ["longbench_prompt_full_1.txt", "longbench_prompt_full_2.txt"]
URL = "http://localhost:8011/v1/completions"
HDR = {"Content-Type": "application/json", "Authorization": "Bearer token-abc123"}
results = {}


def fire(i, pf):
    try:
        p = open(BASE + pf).read()
        body = json.dumps(
            {"model": MP, "prompt": p, "max_tokens": 128, "temperature": 0.0}
        ).encode()
        req = urllib.request.Request(URL, data=body, headers=HDR)
        t0 = time.time()
        r = urllib.request.urlopen(req, timeout=900)
        d = json.loads(r.read())
        txt = d["choices"][0]["text"]
        results[i] = ("OK", round(time.time() - t0, 1), "ntok", len(txt.split()), repr(txt[:90]))
    except Exception as e:
        results[i] = ("ERR", repr(str(e)[:240]))


ths = []
for i, pf in enumerate(PROMPTS):
    t = threading.Thread(target=fire, args=(i, pf))
    t.start()
    ths.append(t)
    time.sleep(2.5)  # stagger: req0 enters decode (compact) while req1 prefills
for t in ths:
    t.join()
for i in sorted(results):
    print("REQ", i, results[i], flush=True)
print("DRIVER_DONE", flush=True)
