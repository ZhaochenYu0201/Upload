# Exp #10 — Cross-family port: SFI on Phi-3.5-MoE

## What this experiment is

Reviewers asked whether SFI generalizes **beyond the Qwen family it was tuned on**. This
ports the sparse method to **Phi-3.5-MoE** (a different MoE architecture) and measures
LongBench-V1 accuracy as a function of the sparse budget `alpha_fair.k_head`, vs the
Phi dense baseline.

## Headline result — budget curve (LongBench-V1, 21 tasks, MAX_MODEL_LEN=131072)

| Config | k_head | Overall | Gap vs dense |
|---|---|---|---|
| **Dense** (FA4 dense gateway) | — | **43.70** | — |
| Sparse | 2016 (Qwen-tuned) | 39.47 | **-4.23** |
| Sparse | 4096 | 40.72 | -2.98 |
| Sparse | 6144 | 41.99 | -1.71 |
| Sparse | 8192 | 42.44 | -1.26 |
| Sparse | **12288** | **43.03** | **-0.67** (~noise) |

Gap shrinks **monotonically** 4.23 → 2.98 → 1.71 → 1.26 → 0.67 as budget grows.

**Conclusion:** SFI is **essentially lossless cross-family** once given an adequate budget
(~6× the Qwen-tuned `k_head`). The gap closes to the run-to-run noise floor; it is **a
budget effect, not a hard family-specific residual**. (An earlier read feared saturation
at ~42.5, but k12288 kept climbing to 43.03, refuting that.)

### Diagnostic detail
- The Qwen-tuned k2016 under-budgets Phi: big drops on retrieval / Chinese few-shot tasks
  (`passage_retrieval_zh` 99→81.5, `lsht` 40.76→24.75). Budget recovers these:
  `passage_retrieval_zh` returns to **99.0 = dense** by k8192.
- **Trigger policy is ~irrelevant cross-family:** `punctuation_tmax` @ k4096 = 40.84 vs
  `fixed_periodic` @ k4096 = 40.72 (= +0.12, noise). The gap is **purely budget**.
- 6-category breakdown at k12288 (and intermediate budgets) is in
  `_raw_result_logs/phi_crossfamily_results.txt`.

## Experimental setup

- **Model:** Phi-3.5-MoE-instruct. **Dense ref:** `V1G_DENSE_CONFIG` / FA4 dense gateway.
- **Hardware:** B200 (FA4 / SM100). **Harness:** LongBench-V1, `LongBench/eval.py`,
  per-task overall over 21 tasks.
- **Sparse:** `gamma=0.5`, `fixed_periodic` trigger, `alpha_fair.k_head` swept
  {2016, 4096, 6144, 8192, 12288}.

## How to run

- Launch scripts in `code/`:
  - `run_longbench_fa4_sparse_b200.sh` — B200 FA4 LongBench-V1 sparse runner
  - `run_longbenchv2_fa4_sparse_b200.sh`, `run_longbenchv2_fa3_sparse_h100.sh` — v2 runners
  - `_lbv2_concurrent_driver.py`, `lbv2_resume_loop.sh` — concurrent driver / resume loop
- Scoring (two-number readout) is documented in `code/eval_instructions.md`
  (`READ_PHI_RESULTS.md`): run `LongBench/eval.py --model <m> --f results_phi_k<budget>`.

## Result files

- Full running log + 6-cat breakdowns: `_raw_result_logs/phi_crossfamily_results.txt`.
- Raw per-budget LongBench prediction dirs on the remote box:
  `…/fast-slow/attention-xx-point/LongBench/results_phi_k{2016,4096,6144,8192,12288}/`
  and `…/results_qwen_dense_v1/` (referenced, not bundled — multi-MB).
