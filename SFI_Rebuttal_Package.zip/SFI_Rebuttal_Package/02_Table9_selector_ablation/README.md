# Exp Table 9 (#3 / #9) — Selector & fusion design ablation

## What this experiment is

Ablation over the **token-selection / score-fusion design** used by the SFI sparse
controller, to show the chosen design is competitive and that the method is not brittle to
this choice. All runs are LongBench-V1, Qwen3-30B-A3B-Instruct, same budget/config except
the selector/fusion variant.

## Headline result (LongBench-V1, 21-task overall)

| Selector / fusion design | Overall |
|---|---|
| `token_topk` | 45.13 |
| `reference` | 44.72 |
| `kn` | 44.39 |
| `pos` | 44.58 |
| **`v2` forward-KL (geometric fusion)** | **45.74** ← filled in this round |
| _arithmetic / reverse-KL (default baseline, = Table 8 γ=0.5)_ | ≈ 44.67 |

**Conclusion:** all five selector/fusion designs land in a tight ~44.4–45.7 band (FA4
sparse run-to-run noise is ~±1). The **geometric / forward-KL** fusion
(`log_s = (1-λ)·log_f + λ·log_r`) is **on par with / slightly above** the default
arithmetic / reverse-KL fusion (`log_s = log[(1-λ)f + λr]`), i.e. forward-KL is a valid,
lossless alternative fusion form. The method is **robust to selector/fusion design**.

## The geometric-fusion variant (what `code/` implements)

The 5th cell (v2 forward-KL / geometric) is implemented as a **1-line CUDA edit** to the
selector kernel (`selector_pipeline_ext.py:1532`, geometric branch), toggled by
`VLLM_SPARSE_FUSION_FORM=geometric`. There is also a **pure-torch** equivalent that needs
**no CUDA recompile** (`hybrid_selectors/alpha_fair_selector.py`), toggled by the same env
plus `VLLM_SPARSE_SELECTOR_CUDA_PIPELINE=0 VLLM_SPARSE_ALPHA_ROWS1_FUSE=0`.

- `code/sync_v2_geometric_puretorch.py` — applies the pure-torch geometric branch
  (idempotent string-replacement; default unset = byte-identical arithmetic baseline).
- `code/sync_v2_geometric_cuda.py` — the CUDA 1-line variant.

The orchestration is **self-managing**: apply edit → launch run → **auto `git checkout`
revert** so the on-disk source is always the arithmetic default (safe for co-tenants who
share the repo). Run on 977964 (B200) GPU0.

## How to run

```bash
# pure-torch geometric (no recompile):
python code/sync_v2_geometric_puretorch.py    # ATTN_REPO defaults to the sfi1 repo
# then launch the LongBench-V1 sparse run with:
#   VLLM_SPARSE_FUSION_FORM=geometric VLLM_SPARSE_SELECTOR_CUDA_PIPELINE=0 \
#   VLLM_SPARSE_ALPHA_ROWS1_FUSE=0  <normal sparse LongBench launch>
# baseline (arithmetic) = leave VLLM_SPARSE_FUSION_FORM unset.
```

## Result files

Numbers + provenance are in `_raw_result_logs/phi_crossfamily_results.txt`
(section "Table 9 第 5 格"). Raw LongBench prediction dirs are on the remote box under
`…/fast-slow/attention-xx-point/LongBench/results_*` (referenced, not bundled).
