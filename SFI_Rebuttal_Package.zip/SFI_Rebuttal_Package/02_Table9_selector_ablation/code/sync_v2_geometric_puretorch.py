#!/usr/bin/env python3
# #3-v2 forward-KL (geometric) via PURE-TORCH path — no CUDA recompile.
# Run on remote: python sync_v2_geometric_puretorch.py
# Then launch with: VLLM_SPARSE_FUSION_FORM=geometric VLLM_SPARSE_SELECTOR_CUDA_PIPELINE=0 VLLM_SPARSE_ALPHA_ROWS1_FUSE=0 ...
# Baseline (arithmetic) = unset VLLM_SPARSE_FUSION_FORM (byte-identical default).
import sys, os
R = os.environ.get("ATTN_REPO", "/mnt/bn/ecom-ai-platform-1/yzc/sfi1/attention-xx-point")
F = R + "/hybrid_selectors/alpha_fair_selector.py"

def replace_once(s, old, new, label):
    n = s.count(old)
    if n == 0:
        if new.split("\n")[0].strip() in s:
            print("[skip] %s already applied" % label); return s
        raise SystemExit("ANCHOR MISSING: %s" % label)
    if n > 1:
        raise SystemExit("ANCHOR NOT UNIQUE (%d): %s" % (n, label))
    print("[ok] %s" % label)
    return s.replace(old, new)

s = open(F).read()

# 1) module-level env read (after ALPHA_ROWS1_FUSE_CACHED)
s = replace_once(
    s,
    '_ALPHA_ROWS1_FUSE_CACHED = os.environ.get("VLLM_SPARSE_ALPHA_ROWS1_FUSE", "1") == "1"',
    '_ALPHA_ROWS1_FUSE_CACHED = os.environ.get("VLLM_SPARSE_ALPHA_ROWS1_FUSE", "1") == "1"\n'
    '_FUSION_GEOMETRIC = os.environ.get("VLLM_SPARSE_FUSION_FORM", "arithmetic") == "geometric"',
    "env read")

# 2) fusion branch (geometric / forward-KL vs arithmetic / reverse-KL default)
old = '    fused = torch.logaddexp(log_one_minus.unsqueeze(-1) + log_f, log_lambda.unsqueeze(-1) + log_r)'
new = (
    '    if _FUSION_GEOMETRIC:\n'
    '        _wf = (1.0 - lam).unsqueeze(-1)\n'
    '        _wr = lam.unsqueeze(-1)\n'
    '        fused = torch.where((log_f > min_val) & (log_r > min_val), _wf * log_f + _wr * log_r, torch.full_like(log_f, min_val))\n'
    '    else:\n'
    '        fused = torch.logaddexp(log_one_minus.unsqueeze(-1) + log_f, log_lambda.unsqueeze(-1) + log_r)')
s = replace_once(s, old, new, "fusion branch")

open(F, "w").write(s)
print("SYNC_V2_DONE", F)
