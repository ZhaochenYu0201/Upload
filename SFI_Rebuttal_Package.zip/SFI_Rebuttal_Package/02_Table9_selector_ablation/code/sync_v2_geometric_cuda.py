#!/usr/bin/env python3
# #3-v2 forward-KL geometric — MINIMAL CUDA edit (1 line in selector_pipeline_ext.py rstring).
# Unconditional geometric (revert after run). Forces .so recompile.
# w_f=exp(log_one_minus)=(1-lam), w_r=exp(log_lambda)=lam (reuse existing shm scalars, no shm change).
import os
R = os.environ.get("ATTN_REPO", "/mnt/bn/ecom-ai-platform-1/yzc/sfi1/attention-xx-point")
F = R + "/utils/selector_pipeline_ext.py"
MODE = os.environ.get("V2MODE", "apply")  # apply | revert
OLD = "    float fused_raw = log_add_exp(log_one_minus + lp, log_lambda + log_r);"
NEW = ("    float _wf = __expf(log_one_minus); float _wr = __expf(log_lambda);\n"
       "    float fused_raw = (lp > min_val && log_r > min_val) ? (_wf * lp + _wr * log_r) : min_val;")
s = open(F).read()
if MODE == "apply":
    if NEW.split("\n")[0] in s:
        print("[skip] geometric already applied"); raise SystemExit(0)
    if s.count(OLD) != 1:
        raise SystemExit("ANCHOR count=%d (need 1)" % s.count(OLD))
    s = s.replace(OLD, NEW); print("[ok] geometric applied (1532)")
else:  # revert
    if OLD in s and NEW.split("\n")[0] not in s:
        print("[skip] already arithmetic"); raise SystemExit(0)
    s = s.replace(NEW, OLD); print("[ok] reverted to arithmetic")
open(F, "w").write(s)
print("V2CUDA_%s_DONE" % MODE.upper(), F)
