# Exp #12 / #14 — Decode throughput / speed-up

## What this experiment is

The efficiency side of the rebuttal: SFI's whole point is a faster decode. This measures
**same-runner decode throughput** of sparse vs dense at long context, to pair with the
near-lossless accuracy results.

## Headline result

- **2.04× decode speed-up at 262k context** (sparse vs dense native FA4, same runner).

The win comes from the effective FA4 `max_seqlen_k` actually dropping below dense capacity
(the sparse route hits and the attended length shrinks), not just from a route being
selected. Speed is real only when **(a)** the effective `max_seqlen_k` drops below dense
capacity **and (b)** same-runner decode beats dense native FA4 — both hold here.

### Methodology notes (what makes a throughput claim valid)
- Measure **same-runner, row-level timing** (warmup + iters, p50/p90), not cumulative
  TPOT (cumulative is polluted by prefill — use **marginal** TPOT for steady decode).
- Crossover with batch size: at small batch / short decode the bootstrap dominates and
  sparse ≈ dense; the **2.04× shows up at long context (262k)** where the attended-length
  reduction dominates. Earlier short-decode (e.g. 512-out) numbers are warmup-polluted —
  use ≥1500-out + marginal timing.

## Experimental setup

- Hardware: NVIDIA **B200** (SM100 / FA4).
- The accepted e2e runner is
  `benchmarks/bench_sm100_fa4_mixed_page_one_shot_graph_e2e.py` (sparse-decode e2e proof),
  which emits `summary.json`, `result_route.jsonl`, and decode metrics per run.
- Compare `--mode sparse` vs `--mode dense` (the dense reference must be measured
  separately; `--mode sparse` only validates correctness against a dense reference, it
  does not by itself time dense).

## How to run

Use the e2e runner with a `RUN_DIR`:

```bash
python benchmarks/bench_sm100_fa4_mixed_page_one_shot_graph_e2e.py --mode sparse  --run-dir <dir_sparse>
python benchmarks/bench_sm100_fa4_mixed_page_one_shot_graph_e2e.py --mode dense   --run-dir <dir_dense>
# then compare marginal decode p50 across the two summary.json / decode metrics
```

(The `*.sh` launch wrappers in the SFI working tree take a `RUN_DIR` argument and set the
`fst_v2` GPU env; they emit `summary.json` + `result_route.jsonl` + decode metrics.)

## Result files

The throughput numbers were produced by the e2e runner on the remote box; the per-run
`summary.json` / `result_route.jsonl` / decode metrics live under the run's `RUN_DIR` on
`/mnt/bn/ecom-ai-platform-1/yzc/...` (referenced, not bundled). Verify any speed claim
against `summary.json` + same-runner row timing rather than a top-level `status=pass`.
